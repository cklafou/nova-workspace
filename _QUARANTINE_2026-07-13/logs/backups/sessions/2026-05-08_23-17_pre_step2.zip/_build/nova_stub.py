"""
Nova.exe -- stub launcher
=========================
Finds the system Python and runs NovaLauncher.py from the workspace.
No nova packages are bundled here -- edits to any .py file in the
workspace take effect on the next launch with zero rebuild required.

Launch behaviour
----------------
If Windows Terminal (wt.exe) is available:
  Opens a single WT window with two tabs:
    Tab 1 — "llama.cpp"  : runs start_llama.cmd  (GPU server)
    Tab 2 — "Nova"       : runs NovaLauncher.py   (app server + Qt UI)
  Both tabs close when the WT window is closed.

Fallback (no wt.exe):
  Starts start_llama.cmd in a separate console window, then runs
  NovaLauncher.py in the current console window.
"""
import sys
import os
import subprocess
import shutil
from pathlib import Path


# ── Python locator ────────────────────────────────────────────────────────────

def find_python() -> str | None:
    # 1. Python on PATH (respects venv / conda activations)
    for name in ("python", "python3"):
        found = shutil.which(name)
        if found and Path(found).exists():
            return found

    # 2. Windows registry -- lists every registered Python install
    try:
        import winreg
        for hive in (winreg.HKEY_CURRENT_USER, winreg.HKEY_LOCAL_MACHINE):
            try:
                key = winreg.OpenKey(hive, r"SOFTWARE\Python\PythonCore")
                i = 0
                while True:
                    try:
                        ver = winreg.EnumKey(key, i)
                        try:
                            inst = winreg.OpenKey(key, ver + r"\InstallPath")
                            exe = winreg.QueryValueEx(inst, "ExecutablePath")[0]
                            if exe and Path(exe).exists():
                                return exe
                        except OSError:
                            pass
                        i += 1
                    except OSError:
                        break
            except OSError:
                pass
    except ImportError:
        pass

    # 3. Common Windows install paths as last resort
    local = Path(os.environ.get("LOCALAPPDATA", ""))
    for candidate in sorted(local.glob("Programs/Python/Python3*/python.exe"), reverse=True):
        if candidate.exists():
            return str(candidate)

    return None


# ── Windows Terminal locator ──────────────────────────────────────────────────

def find_wt() -> str | None:
    """Return path to wt.exe (Windows Terminal), or None."""
    # 1. On PATH
    found = shutil.which("wt")
    if found:
        return found

    # 2. WindowsApps (MSIX install — default on Win 11)
    local = Path(os.environ.get("LOCALAPPDATA", ""))
    for wt in local.glob("Microsoft/WindowsApps/wt.exe"):
        if wt.exists():
            return str(wt)

    # 3. Explicit Program Files locations
    for pf_var in ("ProgramFiles", "ProgramW6432", "ProgramFiles(x86)"):
        pf = os.environ.get(pf_var, "")
        if pf:
            wt = Path(pf) / "Windows Terminal" / "wt.exe"
            if wt.exists():
                return str(wt)

    return None


# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    exe_dir  = Path(sys.executable).resolve().parent
    launcher = exe_dir / "general_tools" / "NovaLauncher.py"
    llama_cmd = exe_dir / "start_llama.cmd"

    # ── Validate required files ───────────────────────────────────────────────
    if not launcher.exists():
        print(f"ERROR: Cannot find NovaLauncher.py at:\n  {launcher}")
        print("Make sure Nova.exe is in the workspace root folder.")
        input("\nPress Enter to exit...")
        sys.exit(1)

    python = find_python()
    if not python:
        print("ERROR: Python not found.")
        print("Install Python from python.org and make sure it is on your PATH.")
        input("\nPress Enter to exit...")
        sys.exit(1)

    wt = find_wt()

    if wt and llama_cmd.exists():
        # ── Windows Terminal: two tabs in one window ──────────────────────────
        # Tab 1: llama.cpp GPU server
        # Tab 2: Nova app (FastAPI + Qt UI)
        # 'cmd /k' keeps each tab alive after the process exits so you can
        # read any final output before closing.
        print(f"Launching via Windows Terminal ({wt})...")

        # wt argument syntax:
        #   wt [options] <profile/cmd> ; new-tab [options] <profile/cmd>
        # Each ';' separates tab definitions.  Quote carefully — wt parses
        # its own command line, so we pass each token individually.
        wt_args = [
            wt,
            # ── Tab 1: llama.cpp ──────────────────────────────────────────
            "--title", "llama.cpp",
            "-d", str(exe_dir),
            "cmd", "/k", str(llama_cmd),
            # ── Tab 2: Nova launcher ──────────────────────────────────────
            ";", "new-tab",
            "--title", "Nova",
            "-d", str(exe_dir),
            "cmd", "/k", python, str(launcher),
        ]
        subprocess.run(wt_args)
        # wt returns immediately after spawning the window; that's expected.

    elif llama_cmd.exists():
        # ── Fallback: separate console windows ───────────────────────────────
        print("Windows Terminal not found — opening llama.cpp in a separate window.")
        subprocess.Popen(
            ["cmd", "/k", str(llama_cmd)],
            cwd=str(exe_dir),
            creationflags=subprocess.CREATE_NEW_CONSOLE,
        )
        # Run Nova launcher in this console
        print(f"Nova launcher -> {python}")
        print(f"             -> {launcher}")
        proc = subprocess.run([python, str(launcher)], cwd=str(exe_dir))
        sys.exit(proc.returncode)

    else:
        # ── No llama cmd found — just launch Nova ────────────────────────────
        print(f"Note: start_llama.cmd not found at {llama_cmd}")
        print(f"Nova launcher -> {python}")
        print(f"             -> {launcher}")
        proc = subprocess.run([python, str(launcher)], cwd=str(exe_dir))
        sys.exit(proc.returncode)


if __name__ == "__main__":
    main()
