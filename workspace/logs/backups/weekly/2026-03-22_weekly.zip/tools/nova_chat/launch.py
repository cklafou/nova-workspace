"""
Nova Group Chat - Launcher
==========================
Run: python tools/nova_chat/launch.py

Spawns the FastAPI server in a NEW terminal window, then opens the browser
and exits -- your original terminal stays free.
"""
import os
import sys
import time
import subprocess
import webbrowser
from pathlib import Path

TOOLS_DIR = Path(__file__).parent.parent
PORT      = 8765
HOST      = "127.0.0.1"
URL       = f"http://{HOST}:{PORT}"


def _write_runner():
    """Write a tiny runner script the new terminal will execute."""
    runner = Path(__file__).parent / "server_runner.py"
    runner.write_text(
        f"""import sys
from pathlib import Path
sys.path.insert(0, str(Path(r'{TOOLS_DIR}')))

import uvicorn
from nova_chat.server import app

print()
print("=" * 52)
print("  NOVA GROUP CHAT  --  http://{HOST}:{PORT}")
print("  Close this window to stop the server.")
print("=" * 52)
print()

uvicorn.run(app, host="{HOST}", port={PORT}, log_level="info")
""",
        encoding="utf-8",
    )
    return runner


def _spawn_windows(runner: Path):
    python = sys.executable
    # Use start+cmd — reliably closes the window when the server exits.
    # wt.exe (Windows Terminal) ignores /c for tab-close and keeps tabs
    # open regardless of process exit, so we skip it.
    subprocess.Popen(
        f'start "Nova Chat Server" cmd /c ""{python}" "{runner}""',
        shell=True,
    )
    return "cmd"


def _spawn_unix(runner: Path):
    python = sys.executable
    cmd = f'"{python}" "{runner}"'
    for term in [
        ["gnome-terminal", "--", "bash", "-c", f"{cmd}; exec bash"],
        ["xterm", "-title", "Nova Chat Server", "-e", cmd],
        ["konsole", "-e", cmd],
        ["x-terminal-emulator", "-e", cmd],
    ]:
        try:
            subprocess.Popen(term)
            return term[0]
        except FileNotFoundError:
            continue
    subprocess.Popen([python, str(runner)], start_new_session=True)
    return "background process"


def main():
    runner = _write_runner()

    print()
    print("=" * 52)
    print("  NOVA GROUP CHAT  --  Launcher")
    print("=" * 52)
    print()

    if sys.platform == "win32":
        term = _spawn_windows(runner)
    else:
        term = _spawn_unix(runner)

    print(f"  Server window : {term}")
    print(f"  URL           : {URL}")
    print()

    # Poll until server is up (max ~5s)
    print("  Waiting for server", end="", flush=True)
    for _ in range(15):
        time.sleep(0.35)
        print(".", end="", flush=True)
        try:
            import urllib.request
            urllib.request.urlopen(URL, timeout=0.4)
            break
        except Exception:
            continue
    print(" ready")
    print()

    print(f"  Opening {URL} in browser...")
    webbrowser.open(URL)
    print()
    print("  This window can be closed.")
    print()


if __name__ == "__main__":
    main()
