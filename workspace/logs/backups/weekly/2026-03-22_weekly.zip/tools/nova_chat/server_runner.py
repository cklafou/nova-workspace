import sys
from pathlib import Path
sys.path.insert(0, str(Path(r'C:\Users\lafou\.openclaw\workspace\tools')))

import uvicorn
from nova_chat.server import app

print()
print("=" * 52)
print("  NOVA GROUP CHAT  --  http://127.0.0.1:8765")
print("  Close this window to stop the server.")
print("=" * 52)
print()

uvicorn.run(app, host="127.0.0.1", port=8765, log_level="info")
