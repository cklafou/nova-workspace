#!/usr/bin/env python3
"""
Backup Vision API integration for Nova's computer control.
This is the original implementation that uses pyautogui for screenshots and basic image matching.
"""
import pyautogui
import json
import time
import os
from pathlib import Path
from typing import Tuple, List, Dict, Optional
import cv2
import numpy as np
from PIL import Image

class NovaVision:
    def __init__(self):
        """Initialize the vision system"""
        self.screenshot_dir = "logs/screenshots"
        os.makedirs(self.screenshot_dir, exist_ok=True)
        
    def take_screenshot(self, region: Optional[Tuple[int, int, int, int]] = None) -> Image.Image:
        """
        Take a screenshot of the screen or specified region
        Args:
            region: (x, y, width, height) tuple for partial screenshot
        Returns:
            PIL Image object
        """
        if region:
            screenshot = pyautogui.screenshot(region=region)
        else:
            screenshot = pyautogui.screenshot()
        
        # Save screenshot for review
        timestamp = int(time.time())
        filename = f"screenshot_{timestamp}.png"
        filepath = os.path.join(self.screenshot_dir, filename)
        screenshot.save(filepath)
        
        print(f"Screenshot saved to {filepath}")
        return screenshot
    
    def locate_element(self, image_path: str, screenshot: Optional[Image.Image] = None) -> Optional[Tuple[int, int]]:
        """
        Locate an element (image) within a screenshot
        This is a placeholder that would use actual image matching or Vision API
        for now it will use pyautogui's built-in locateOnScreen functionality
        """
        try:
            if screenshot:
                # If we have a specific screenshot already, use it
                pass  # In a real implementation, we'd compare against this
            else:
                # Take a new screenshot
                screenshot = self.take_screenshot()
            
            # Use pyautogui to find the element (will raise exception if not found)
            location = pyautogui.locateOnScreen(image_path, confidence=0.8)
            if location:
                center_x = location.left + location.width // 2
                center_y = location.top + location.height // 2
                print(f"Found element at: ({center_x}, {center_y})")
                return (center_x, center_y)
            
        except pyautogui.ImageNotFoundException:
            print(f"Element not found in screenshot: {image_path}")
            return None
        except Exception as e:
            print(f"Error locating element: {e}")
            return None
        
        return None
    
    def screen_to_coordinates(self, screen_x: int, screen_y: int) -> Tuple[int, int]:
        """
        Convert screen coordinates to relative coordinates if needed
        For now returns same coordinates since we're working at screen level
        """
        return (screen_x, screen_y)
    
    def get_screen_dimensions(self) -> Tuple[int, int]:
        """
        Get the current screen dimensions
        """
        return (pyautogui.size())
    
    def find_and_click_element(self, element_image_path: str, confidence: float = 0.8) -> bool:
        """
        Find an element on screen and click it
        """
        try:
            # Take screenshot and locate element
            location = pyautogui.locateOnScreen(element_image_path, confidence=confidence)
            if location:
                # Click on the center of the located element
                center_x = location.left + location.width // 2
                center_y = location.top + location.height // 2
                pyautogui.click(center_x, center_y)
                print(f"Clicked on element at ({center_x}, {center_y})")
                return True
            else:
                print(f"Element not found: {element_image_path}")
                return False
        except Exception as e:
            print(f"Error clicking element: {e}")
            return False
    
    def save_element_template(self, element_name: str, region: Tuple[int, int, int, int]) -> str:
        """
        Save a region of the screen as an element template for later matching
        """
        try:
            screenshot = pyautogui.screenshot(region=region)
            filename = f"{element_name}_{int(time.time())}.png"
            filepath = os.path.join(self.screenshot_dir, filename)
            screenshot.save(filepath)
            print(f"Saved element template: {filepath}")
            return filepath
        except Exception as e:
            print(f"Error saving element template: {e}")
            return ""
    
    def analyze_screen(self, screenshot: Image.Image = None) -> Dict:
        """
        Analyze screen content - this would ideally use Vision API
        For now returns basic information about screenshot
        """
        if screenshot is None:
            screenshot = self.take_screenshot()
            
        width, height = screenshot.size
        return {
            "dimensions": {"width": width, "height": height},
            "format": screenshot.format,
            "mode": screenshot.mode,
            "timestamp": time.time()
        }

def main():
    """Main function for vision system testing"""
    print("=== Nova Vision System (Backup) ===")
    
    # Initialize vision system
    vision = NovaVision()
    
    # Test basic functionality
    try:
        # Get screen dimensions
        width, height = vision.get_screen_dimensions()
        print(f"Screen dimensions: {width} x {height}")
        
        # Take a test screenshot
        screenshot = vision.take_screenshot()
        print(f"Test screenshot taken")
        
        # Analyze the screenshot
        analysis = vision.analyze_screen(screenshot)
        print(f"Screenshot analysis: {analysis}")
        
        print("Vision system initialized successfully!")
        
    except Exception as e:
        print(f"Error initializing vision system: {e}")

if __name__ == "__main__":
    main()