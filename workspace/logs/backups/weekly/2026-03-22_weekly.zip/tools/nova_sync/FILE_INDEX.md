# FILE_INDEX.md -- Nova Workspace Raw File Index
_Auto-generated on boot by nova_sync/watcher.py. Do not edit manually._
_Last updated: 2026-03-22 00:02:50_
_cache_key: 0000491_

Claude: all URLs below use a commit hash -- they are cache-proof.
Fetch any URL directly. No ?t= needed.
Example: https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/tools/nova_sync/watcher.py

## Root
- .clawhub/ (excluded)
- [AGENTS.md](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/AGENTS.md)
- [BOOTSTRAP.md](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/BOOTSTRAP.md)
- [HEARTBEAT.md](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/HEARTBEAT.md)
- [IDENTITY.md](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/IDENTITY.md)
- node_modules/ (excluded)
- [README.md](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/README.md)
- [SOUL.md](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/SOUL.md)
- [TOOLS.md](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/TOOLS.md)
- [USER.md](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/USER.md)

## logs/
- [logs/autonomy_test.py](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/logs/autonomy_test.py)
- logs/backups/sessions/2026-03-21_18-46_session.zip
- logs/backups/sessions/2026-03-21_18-55_session.zip
- logs/backups/sessions/2026-03-21_19-14_session.zip
- logs/backups/sessions/2026-03-21_19-23_session.zip
- logs/backups/sessions/2026-03-21_19-24_session.zip
- logs/backups/sessions/2026-03-21_19-30_session.zip
- logs/backups/sessions/2026-03-21_19-38_session.zip
- logs/backups/sessions/2026-03-21_19-48_session.zip
- logs/backups/sessions/2026-03-21_19-52_session.zip
- logs/backups/sessions/2026-03-21_19-53_session.zip
- logs/backups/sessions/2026-03-21_19-56_session.zip
- logs/backups/sessions/2026-03-21_20-01_session.zip
- logs/backups/sessions/2026-03-21_20-07_session.zip
- logs/backups/sessions/2026-03-21_20-18_session.zip
- logs/backups/sessions/2026-03-21_20-22_session.zip
- logs/backups/sessions/2026-03-21_20-28_session.zip
- logs/backups/sessions/2026-03-21_20-33_session.zip
- logs/backups/sessions/2026-03-21_20-38_session.zip
- logs/backups/sessions/2026-03-21_20-50_session.zip
- logs/backups/sessions/2026-03-21_20-56_session.zip
- logs/backups/sessions/2026-03-21_21-04_session.zip
- logs/backups/sessions/2026-03-21_21-12_session.zip
- logs/backups/sessions/2026-03-21_22-11_session.zip
- logs/backups/sessions/2026-03-21_22-59_session.zip
- logs/backups/sessions/2026-03-21_23-00_session.zip
- logs/backups/sessions/2026-03-21_23-02_session.zip
- logs/backups/sessions/2026-03-21_23-12_session.zip
- logs/backups/sessions/2026-03-21_23-29_session.zip
- logs/backups/sessions/2026-03-21_23-39_session.zip
- logs/backups/sessions/2026-03-21_23-49_session.zip
- [logs/chat_sessions/2026-03-21_16-46-47_chat.jsonl](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/logs/chat_sessions/2026-03-21_16-46-47_chat.jsonl)
- [logs/chat_sessions/2026-03-21_19-26-26_chat.jsonl](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/logs/chat_sessions/2026-03-21_19-26-26_chat.jsonl)
- logs/chat_sessions/2026-03-21_19-26-26_chat.jsonl.gz
- [logs/chat_sessions/sessions_index.json](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/logs/chat_sessions/sessions_index.json)
- [logs/passover/3%20MAR%202026/passover_2026-03-10.md](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/logs/passover/3%20MAR%202026/passover_2026-03-10.md)
- [logs/passover/3%20MAR%202026/passover_2026-03-15.md](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/logs/passover/3%20MAR%202026/passover_2026-03-15.md)
- [logs/passover/3%20MAR%202026/passover_2026-03-19.md](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/logs/passover/3%20MAR%202026/passover_2026-03-19.md)
- [logs/passover/3%20MAR%202026/passover_2026-03-20.md](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/logs/passover/3%20MAR%202026/passover_2026-03-20.md)
- [logs/passover/3%20MAR%202026/passover_2026-03-20_gemini.md](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/logs/passover/3%20MAR%202026/passover_2026-03-20_gemini.md)
- [logs/passover/3%20MAR%202026/passover_2026-03-21_claude.md](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/logs/passover/3%20MAR%202026/passover_2026-03-21_claude.md)
- [logs/passover/3%20MAR%202026/passover_2026-03-21_gemini.md](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/logs/passover/3%20MAR%202026/passover_2026-03-21_gemini.md)
- [logs/passover/3%20MAR%202026/passover_2026-03-21_gemini_session2.md](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/logs/passover/3%20MAR%202026/passover_2026-03-21_gemini_session2.md)
- [logs/proposed/STATUS.md](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/logs/proposed/STATUS.md)
- [logs/sessions/2026-03-19/mentor.jsonl](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/logs/sessions/2026-03-19/mentor.jsonl)
- [logs/sessions/2026-03-20/mentor.jsonl](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/logs/sessions/2026-03-20/mentor.jsonl)
- [logs/sessions/2026-03-20/stress_test.jsonl](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/logs/sessions/2026-03-20/stress_test.jsonl)

## memory/
- [memory/archive/archive_2026-02.md](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/memory/archive/archive_2026-02.md)
- [memory/COLE.md](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/memory/COLE.md)
- [memory/JOURNAL.md](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/memory/JOURNAL.md)
- [memory/session_start.json](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/memory/session_start.json)
- [memory/STATUS.md](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/memory/STATUS.md)

## skills/
- skills/automation-workflows/.clawhub/ (excluded)
- [skills/automation-workflows/_meta.json](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/skills/automation-workflows/_meta.json)
- [skills/automation-workflows/SKILL.md](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/skills/automation-workflows/SKILL.md)
- skills/discord-voice-deepgram/.clawhub/ (excluded)
- [skills/discord-voice-deepgram/_meta.json](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/skills/discord-voice-deepgram/_meta.json)
- [skills/discord-voice-deepgram/clawdbot.plugin.json](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/skills/discord-voice-deepgram/clawdbot.plugin.json)
- skills/discord-voice-deepgram/index.ts
- [skills/discord-voice-deepgram/package.json](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/skills/discord-voice-deepgram/package.json)
- [skills/discord-voice-deepgram/SKILL.md](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/skills/discord-voice-deepgram/SKILL.md)
- skills/discord-voice-deepgram/src/config.ts
- skills/discord-voice-deepgram/src/core-bridge.ts
- skills/discord-voice-deepgram/src/streaming-stt.ts
- skills/discord-voice-deepgram/src/streaming-tts.ts
- skills/discord-voice-deepgram/src/stt.ts
- skills/discord-voice-deepgram/src/tts.ts
- skills/discord-voice-deepgram/src/voice-connection.ts
- [skills/discord-voice-deepgram/tsconfig.json](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/skills/discord-voice-deepgram/tsconfig.json)
- skills/github/.clawhub/ (excluded)
- [skills/github/_meta.json](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/skills/github/_meta.json)
- [skills/github/SKILL.md](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/skills/github/SKILL.md)
- skills/playwright-scraper-skill/.clawhub/ (excluded)
- [skills/playwright-scraper-skill/_meta.json](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/skills/playwright-scraper-skill/_meta.json)
- [skills/playwright-scraper-skill/CHANGELOG.md](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/skills/playwright-scraper-skill/CHANGELOG.md)
- [skills/playwright-scraper-skill/CONTRIBUTING.md](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/skills/playwright-scraper-skill/CONTRIBUTING.md)
- skills/playwright-scraper-skill/examples/discuss-hk.sh
- [skills/playwright-scraper-skill/examples/README.md](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/skills/playwright-scraper-skill/examples/README.md)
- [skills/playwright-scraper-skill/INSTALL.md](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/skills/playwright-scraper-skill/INSTALL.md)
- [skills/playwright-scraper-skill/package-lock.json](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/skills/playwright-scraper-skill/package-lock.json)
- [skills/playwright-scraper-skill/package.json](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/skills/playwright-scraper-skill/package.json)
- [skills/playwright-scraper-skill/README.md](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/skills/playwright-scraper-skill/README.md)
- [skills/playwright-scraper-skill/README_ZH.md](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/skills/playwright-scraper-skill/README_ZH.md)
- skills/playwright-scraper-skill/scripts/playwright-simple.js
- skills/playwright-scraper-skill/scripts/playwright-stealth.js
- [skills/playwright-scraper-skill/SKILL.md](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/skills/playwright-scraper-skill/SKILL.md)
- skills/playwright-scraper-skill/test.sh

## tools/
- tools/backups/ (excluded)
- [tools/logs/sessions/2026-03-21/nova_thoughts.jsonl](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/tools/logs/sessions/2026-03-21/nova_thoughts.jsonl)
- [tools/nova_action/__init__.py](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/tools/nova_action/__init__.py)
- tools/nova_action/__pycache__/ (excluded)
- [tools/nova_action/autonomy.py](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/tools/nova_action/autonomy.py)
- [tools/nova_action/hands.py](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/tools/nova_action/hands.py)
- [tools/nova_action/verify.py](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/tools/nova_action/verify.py)
- [tools/nova_advisor/__init__.py](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/tools/nova_advisor/__init__.py)
- tools/nova_advisor/__pycache__/ (excluded)
- [tools/nova_advisor/mentor.py](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/tools/nova_advisor/mentor.py)
- tools/nova_chat/__pycache__/ (excluded)
- [tools/nova_chat/check_keys.py](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/tools/nova_chat/check_keys.py)
- tools/nova_chat/clients/__pycache__/ (excluded)
- [tools/nova_chat/clients/claude.py](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/tools/nova_chat/clients/claude.py)
- [tools/nova_chat/clients/gemini.py](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/tools/nova_chat/clients/gemini.py)
- [tools/nova_chat/clients/nova.py](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/tools/nova_chat/clients/nova.py)
- [tools/nova_chat/context_export.py](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/tools/nova_chat/context_export.py)
- [tools/nova_chat/launch.py](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/tools/nova_chat/launch.py)
- [tools/nova_chat/nova_bridge.py](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/tools/nova_chat/nova_bridge.py)
- [tools/nova_chat/orchestrator.py](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/tools/nova_chat/orchestrator.py)
- [tools/nova_chat/server.py](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/tools/nova_chat/server.py)
- [tools/nova_chat/server_runner.py](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/tools/nova_chat/server_runner.py)
- [tools/nova_chat/session_manager.py](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/tools/nova_chat/session_manager.py)
- tools/nova_chat/static/index.html
- [tools/nova_chat/transcript.py](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/tools/nova_chat/transcript.py)
- [tools/nova_chat/workspace_context.py](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/tools/nova_chat/workspace_context.py)
- [tools/nova_core/__init__.py](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/tools/nova_core/__init__.py)
- tools/nova_core/__pycache__/ (excluded)
- [tools/nova_core/brain.py](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/tools/nova_core/brain.py)
- [tools/nova_core/checkin.py](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/tools/nova_core/checkin.py)
- [tools/nova_core/rules.py](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/tools/nova_core/rules.py)
- [tools/nova_memory/__init__.py](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/tools/nova_memory/__init__.py)
- tools/nova_memory/__pycache__/ (excluded)
- [tools/nova_memory/journal.py](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/tools/nova_memory/journal.py)
- [tools/nova_memory/log_reader.py](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/tools/nova_memory/log_reader.py)
- [tools/nova_memory/logger.py](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/tools/nova_memory/logger.py)
- [tools/nova_memory/state.py](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/tools/nova_memory/state.py)
- [tools/nova_memory/status.py](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/tools/nova_memory/status.py)
- [tools/nova_patch.py](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/tools/nova_patch.py)
- [tools/nova_perception/__init__.py](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/tools/nova_perception/__init__.py)
- tools/nova_perception/__pycache__/ (excluded)
- [tools/nova_perception/explorer.py](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/tools/nova_perception/explorer.py)
- [tools/nova_perception/eyes.py](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/tools/nova_perception/eyes.py)
- [tools/nova_perception/vision.py](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/tools/nova_perception/vision.py)
- [tools/nova_perception/vision_backup.py](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/tools/nova_perception/vision_backup.py)
- [tools/nova_restructure.py](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/tools/nova_restructure.py)
- [tools/nova_stress_tester.py](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/tools/nova_stress_tester.py)
- [tools/nova_sync/__init__.py](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/tools/nova_sync/__init__.py)
- tools/nova_sync/__pycache__/ (excluded)
- [tools/nova_sync/backup.py](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/tools/nova_sync/backup.py)
- [tools/nova_sync/dir_patch.py](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/tools/nova_sync/dir_patch.py)
- [tools/nova_sync/drive.py](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/tools/nova_sync/drive.py)
- tools/nova_sync/FILE_INDEX.md
- [tools/nova_sync/FILE_INDEX_LINK.md](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/tools/nova_sync/FILE_INDEX_LINK.md)
- [tools/nova_sync/GEMINI_INDEX.md](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/tools/nova_sync/GEMINI_INDEX.md)
- [tools/nova_sync/watcher.py](https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/tools/nova_sync/watcher.py)
