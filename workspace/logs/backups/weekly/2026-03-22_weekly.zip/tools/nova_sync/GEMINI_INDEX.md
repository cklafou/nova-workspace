# GEMINI_INDEX.md -- Nova Workspace Session Manifest
_Last updated: 2026-03-22 00:03:20_

## INITIALIZATION PROTOCOL
Run these three steps at the start of every session in order:

```
Step 1: @Google Drive: Search for the folder 'Nova_Workspace'
Step 2: @Google Drive: Search for 'workspace/tools/nova_sync/GEMINI_INDEX.md'
Step 3: Refer to the Search Key column below for all subsequent file lookups.
```

**Rule: Never guess a path. Only search using the exact string in the Search Key column.**

## START HERE EVERY SESSION

| File | Search Key | Description |
|------|-----------|-------------|
| STATUS.md | `workspace/memory/STATUS.md` | Current project state -- READ FIRST |
| JOURNAL.md | `workspace/memory/JOURNAL.md` | Nova's session log -- READ SECOND |
| COLE.md | `workspace/memory/COLE.md` | Who Cole is and Nova's notes |
| TOOLS.md | `workspace/TOOLS.md` | Tool reference and exec patterns |
| BOOTSTRAP.md | `workspace/BOOTSTRAP.md` | Session startup sequence |

## Root Files

| Filename | Search Key | Description |
|----------|-----------|-------------|
| AGENTS.md | `workspace/AGENTS.md` | Nova's operating rules and agent behavior definitions |
| BOOTSTRAP.md | `workspace/BOOTSTRAP.md` | Boot sequence Nova follows on every OpenClaw start |
| HEARTBEAT.md | `workspace/HEARTBEAT.md` | Current heartbeat state |
| IDENTITY.md | `workspace/IDENTITY.md` | Nova's self-definition document |
| README.md | `workspace/README.md` | Project overview |
| SOUL.md | `workspace/SOUL.md` | Nova's identity, values, and growth framework |
| TOOLS.md | `workspace/TOOLS.md` | How to use all tools, method reference, exec patterns |
| USER.md | `workspace/USER.md` | Who Cole is -- personality, background, preferences |

## memory/

| Filename | Search Key | Description |
|----------|-----------|-------------|
| .drive_sync_cache.json | `workspace/memory/.drive_sync_cache.json` | JSON file |
| archive_2026-02.md | `workspace/memory/archive/archive_2026-02.md` | MD file |
| COLE.md | `workspace/memory/COLE.md` | Cole's notes and Nova's observations about Cole |
| JOURNAL.md | `workspace/memory/JOURNAL.md` | Nova's running session log -- READ SECOND |
| session_start.json | `workspace/memory/session_start.json` | Current session start timestamp |
| STATUS.md | `workspace/memory/STATUS.md` | Current project state and mission -- READ FIRST |

## tools/

| Filename | Search Key | Description |
|----------|-----------|-------------|
| nova_thoughts.jsonl | `workspace/tools/logs/sessions/2026-03-21/nova_thoughts.jsonl` | JSONL file |
| __init__.py | `workspace/tools/nova_action/__init__.py` | PY file |
| autonomy.py | `workspace/tools/nova_action/autonomy.py` | FIND->COMMIT->VERIFY action loop with interrupt polling |
| hands.py | `workspace/tools/nova_action/hands.py` | Mouse/keyboard control via pyautogui + pynput |
| verify.py | `workspace/tools/nova_action/verify.py` | Action verification helpers |
| __init__.py | `workspace/tools/nova_advisor/__init__.py` | PY file |
| mentor.py | `workspace/tools/nova_advisor/mentor.py` | Claude Sonnet + Haiku advisor -- GROWTH MODE, gatekeeper |
| check_keys.py | `workspace/tools/nova_chat/check_keys.py` | PY file |
| claude.py | `workspace/tools/nova_chat/clients/claude.py` | PY file |
| gemini.py | `workspace/tools/nova_chat/clients/gemini.py` | PY file |
| nova.py | `workspace/tools/nova_chat/clients/nova.py` | PY file |
| context_export.py | `workspace/tools/nova_chat/context_export.py` | PY file |
| launch.py | `workspace/tools/nova_chat/launch.py` | PY file |
| nova_bridge.py | `workspace/tools/nova_chat/nova_bridge.py` | PY file |
| orchestrator.py | `workspace/tools/nova_chat/orchestrator.py` | PY file |
| server.py | `workspace/tools/nova_chat/server.py` | PY file |
| server_runner.py | `workspace/tools/nova_chat/server_runner.py` | PY file |
| session_manager.py | `workspace/tools/nova_chat/session_manager.py` | PY file |
| transcript.py | `workspace/tools/nova_chat/transcript.py` | PY file |
| workspace_context.py | `workspace/tools/nova_chat/workspace_context.py` | PY file |
| __init__.py | `workspace/tools/nova_core/__init__.py` | PY file |
| brain.py | `workspace/tools/nova_core/brain.py` | Companion-first cognitive router |
| checkin.py | `workspace/tools/nova_core/checkin.py` | Inter-turn message listener and session init |
| rules.py | `workspace/tools/nova_core/rules.py` | Immutable operating directives and yield protocol |
| __init__.py | `workspace/tools/nova_memory/__init__.py` | PY file |
| journal.py | `workspace/tools/nova_memory/journal.py` | Append-only JOURNAL.md writer with sanitize() |
| log_reader.py | `workspace/tools/nova_memory/log_reader.py` | Reads session logs -- summarize_today(), get_failures() |
| logger.py | `workspace/tools/nova_memory/logger.py` | Dated log folder manager |
| state.py | `workspace/tools/nova_memory/state.py` | Pre-condition state checking before any action |
| status.py | `workspace/tools/nova_memory/status.py` | STATUS.md proposed-changes updater |
| nova_patch.py | `workspace/tools/nova_patch.py` | Post-restructure import patcher and test runner |
| __init__.py | `workspace/tools/nova_perception/__init__.py` | PY file |
| explorer.py | `workspace/tools/nova_perception/explorer.py` | pywinauto accessibility API wrapper -- exact UI coordinates |
| eyes.py | `workspace/tools/nova_perception/eyes.py` | Unified vision -- pywinauto first, Claude Haiku fallback |
| vision.py | `workspace/tools/nova_perception/vision.py` | Claude Haiku screen verification and description |
| vision_backup.py | `workspace/tools/nova_perception/vision_backup.py` | Backup vision implementation using basic image matching |
| nova_restructure.py | `workspace/tools/nova_restructure.py` | One-time package migration script (keep for reference) |
| nova_stress_tester.py | `workspace/tools/nova_stress_tester.py` | Failure mode testing framework |
| .drive_sync_cache.json | `workspace/tools/nova_sync/.drive_sync_cache.json` | JSON file |
| __init__.py | `workspace/tools/nova_sync/__init__.py` | PY file |
| backup.py | `workspace/tools/nova_sync/backup.py` | Session snapshots on boot, weekly full backups on Sundays |
| dir_patch.py | `workspace/tools/nova_sync/dir_patch.py` | Import path auditor -- scans .py and .md for stale references |
| drive.py | `workspace/tools/nova_sync/drive.py` | Google Drive diff-based sync (this system) |
| FILE_INDEX.md | `workspace/tools/nova_sync/FILE_INDEX.md` | Full workspace file listing with GitHub URLs (for Claude) |
| FILE_INDEX_LINK.md | `workspace/tools/nova_sync/FILE_INDEX_LINK.md` | Claude's bootstrap URL pointer |
| watcher.py | `workspace/tools/nova_sync/watcher.py` | GitHub sync + Drive sync + backup. Modes: --push, --pup, --full |

## logs/

| Filename | Search Key | Description |
|----------|-----------|-------------|
| autonomy_test.py | `workspace/logs/autonomy_test.py` | PY file |
| 2026-03-21_16-46-47_chat.jsonl | `workspace/logs/chat_sessions/2026-03-21_16-46-47_chat.jsonl` | JSONL file |
| 2026-03-21_19-26-26_chat.jsonl | `workspace/logs/chat_sessions/2026-03-21_19-26-26_chat.jsonl` | JSONL file |
| sessions_index.json | `workspace/logs/chat_sessions/sessions_index.json` | JSON file |
| passover_2026-03-10.md | `workspace/logs/passover/3 MAR 2026/passover_2026-03-10.md` | MD file |
| passover_2026-03-15.md | `workspace/logs/passover/3 MAR 2026/passover_2026-03-15.md` | MD file |
| passover_2026-03-19.md | `workspace/logs/passover/3 MAR 2026/passover_2026-03-19.md` | MD file |
| passover_2026-03-20.md | `workspace/logs/passover/3 MAR 2026/passover_2026-03-20.md` | MD file |
| passover_2026-03-20_gemini.md | `workspace/logs/passover/3 MAR 2026/passover_2026-03-20_gemini.md` | MD file |
| passover_2026-03-21_claude.md | `workspace/logs/passover/3 MAR 2026/passover_2026-03-21_claude.md` | MD file |
| passover_2026-03-21_gemini.md | `workspace/logs/passover/3 MAR 2026/passover_2026-03-21_gemini.md` | MD file |
| passover_2026-03-21_gemini_session2.md | `workspace/logs/passover/3 MAR 2026/passover_2026-03-21_gemini_session2.md` | MD file |
| STATUS.md | `workspace/logs/proposed/STATUS.md` | Current project state and mission -- READ FIRST |
| mentor.jsonl | `workspace/logs/sessions/2026-03-19/mentor.jsonl` | JSONL file |
| mentor.jsonl | `workspace/logs/sessions/2026-03-20/mentor.jsonl` | JSONL file |
| stress_test.jsonl | `workspace/logs/sessions/2026-03-20/stress_test.jsonl` | JSONL file |

## skills/

| Filename | Search Key | Description |
|----------|-----------|-------------|
| _meta.json | `workspace/skills/automation-workflows/_meta.json` | JSON file |
| SKILL.md | `workspace/skills/automation-workflows/SKILL.md` | MD file |
| _meta.json | `workspace/skills/discord-voice-deepgram/_meta.json` | JSON file |
| clawdbot.plugin.json | `workspace/skills/discord-voice-deepgram/clawdbot.plugin.json` | JSON file |
| package.json | `workspace/skills/discord-voice-deepgram/package.json` | JSON file |
| SKILL.md | `workspace/skills/discord-voice-deepgram/SKILL.md` | MD file |
| tsconfig.json | `workspace/skills/discord-voice-deepgram/tsconfig.json` | JSON file |
| _meta.json | `workspace/skills/github/_meta.json` | JSON file |
| SKILL.md | `workspace/skills/github/SKILL.md` | MD file |
| _meta.json | `workspace/skills/playwright-scraper-skill/_meta.json` | JSON file |
| CHANGELOG.md | `workspace/skills/playwright-scraper-skill/CHANGELOG.md` | MD file |
| CONTRIBUTING.md | `workspace/skills/playwright-scraper-skill/CONTRIBUTING.md` | MD file |
| README.md | `workspace/skills/playwright-scraper-skill/examples/README.md` | Project overview |
| INSTALL.md | `workspace/skills/playwright-scraper-skill/INSTALL.md` | MD file |
| package-lock.json | `workspace/skills/playwright-scraper-skill/package-lock.json` | JSON file |
| package.json | `workspace/skills/playwright-scraper-skill/package.json` | JSON file |
| README.md | `workspace/skills/playwright-scraper-skill/README.md` | Project overview |
| README_ZH.md | `workspace/skills/playwright-scraper-skill/README_ZH.md` | MD file |
| SKILL.md | `workspace/skills/playwright-scraper-skill/SKILL.md` | MD file |

---
_This manifest is auto-generated on every Drive sync by nova_sync/drive.py._
_Do not edit manually -- changes will be overwritten._