https://raw.githubusercontent.com/cklafou/nova-workspace/6ab47e0da68f7aa75abf66b192d61717bbbff250/workspace/tools/nova_sync/FILE_INDEX.md
