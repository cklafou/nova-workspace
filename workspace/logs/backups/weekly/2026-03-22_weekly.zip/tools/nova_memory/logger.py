#!/usr/bin/env python3
# Last updated: 2026-03-19 21:42:21
"""
nova_logger.py — Nova's Log Manager
======================================
This module handles ALL logging for the Nova project.

Every other module (nova_autonomy, nova_vision, nova_mentor, nova_interrupt)
imports and uses THIS module instead of writing to log files directly.

Why this exists:
  Without this, each module writes to its own hardcoded file path.
  Nova could run past midnight and today's logs would mix with yesterday's.
  Tracking down what happened on a specific day would be a nightmare.

What this does:
  1. Knows the current date at all times
  2. Creates a dated folder automatically: logs/sessions/YYYY-MM-DD/
  3. Detects when the date changes (midnight rollover) and switches folders
  4. Gives every module a simple one-line way to log anything

Log structure this creates:
  logs/
  ├── sessions/
  │   ├── 2026-03-11/
  │   │   ├── actions.jsonl      <- clicks, retries, successes
  │   │   ├── interrupts.jsonl   <- Cole's messages + Nova's responses
  │   │   ├── mentor.jsonl       <- Mentor/Claude consultations
  │   │   └── errors.jsonl       <- anything that went wrong today
  │   └── 2026-03-12/            <- new folder auto-created at midnight
  │       └── ...
  ├── screenshots/
  │   ├── 2026-03-11/            <- screenshots organized by date
  │   └── 2026-03-12/
  └── errors.jsonl               <- persistent error log (ALL time, never rotated)

How to use in other modules:
  # At the top of any Nova module:
  from nova_memory.logger import log, get_screenshot_dir

  # Log an action:
  log("actions", "success", target="Login button", action="click", result="ok")

  # Log a mentor consultation:
  log("mentor", "nova_question", message="I can't find the tab", context="attempt 3")

  # Log an interrupt:
  log("interrupts", "message_received", message="stop", classification="URGENT")

  # Get today's screenshot directory (auto-created):
  shot_dir = get_screenshot_dir()
  screenshot.save(shot_dir / f"shot_{int(time.time())}.png")
"""

import json
import time
import threading
from datetime import datetime
from pathlib import Path

# ── Base paths ─────────────────────────────────────────────────────────────────

# Root of the logs directory — everything lives under here
LOGS_ROOT        = Path("logs")

# Sessions go in dated subfolders: logs/sessions/YYYY-MM-DD/
SESSIONS_ROOT    = LOGS_ROOT / "sessions"

# Screenshots go in dated subfolders: logs/screenshots/YYYY-MM-DD/
SCREENSHOTS_ROOT = LOGS_ROOT / "screenshots"

# Persistent error log — never rotated, spans all sessions
PERSISTENT_ERRORS = LOGS_ROOT / "errors.jsonl"


# ── The log manager ────────────────────────────────────────────────────────────

class NovaLogger:
    """
    Central log manager for all Nova modules.

    Tracks the current date and automatically switches to a new folder
    at midnight so logs are always organized by day.

    This is a singleton — only one instance should exist.
    Use the module-level log() function instead of instantiating directly.
    """

    def __init__(self):
        # The date we are currently logging to
        # Updated automatically when the date changes
        self._current_date = self._today()

        # Lock to prevent two threads writing to the same file simultaneously
        # (Important since nova_interrupt runs in a background thread)
        self._lock = threading.Lock()

        # Create the base directory structure on first run
        self._ensure_dirs()

        print(f"[logger] NovaLogger initialized. Logging to: {self._session_dir()}")

    # ── Public: log an entry ───────────────────────────────────────────────────

    def log(self, log_type: str, event: str, **fields):
        """
        Write a log entry to today's dated session folder.

        Args:
            log_type: Which log file to write to.
                      Options: 'actions', 'interrupts', 'mentor', 'errors'
                      This maps to logs/sessions/YYYY-MM-DD/{log_type}.jsonl

            event:    A short label describing what happened.
                      Examples: 'success', 'sight_fail', 'message_received'

            **fields: Any additional data to include in the log entry.
                      These become key-value pairs in the JSON object.
                      Examples:
                        target="Login button"
                        action="click"
                        result="ok"
                        message="I can't find the tab"

        Examples:
            log("actions",    "success",          target="Login button", action="click")
            log("actions",    "sight_fail",        target="Buy button",   attempt="2/3")
            log("mentor",     "nova_question",     message="What should I try?")
            log("mentor",     "mentor_response",   message="Try clicking the taskbar first")
            log("interrupts", "message_received",  message="stop", classification="URGENT")
            log("errors",     "exception",         module="nova_vision", error="API timeout")
        """
        # Check if the date has changed since last log entry
        # This handles Nova running past midnight
        self._check_date_rollover()

        # Build the log entry
        entry = {
            "timestamp": datetime.now().isoformat(),
            "event":     event,
            **fields      # unpack all the extra fields into the JSON object
        }

        # Write to the appropriate file with thread safety
        log_file = self._session_dir() / f"{log_type}.jsonl"
        with self._lock:
            with open(log_file, "a") as f:
                f.write(json.dumps(entry) + "\n")

        # Errors also go to the persistent error log that spans all sessions
        if log_type == "errors":
            entry["date"] = self._current_date   # add date since this spans multiple days
            with self._lock:
                with open(PERSISTENT_ERRORS, "a") as f:
                    f.write(json.dumps(entry) + "\n")

    # ── Public: get today's screenshot directory ───────────────────────────────

    def get_screenshot_dir(self) -> Path:
        """
        Get the path to today's screenshot folder.
        Creates it if it doesn't exist yet.

        Returns:
            Path object pointing to logs/screenshots/YYYY-MM-DD/

        Example:
            shot_dir = logger.get_screenshot_dir()
            screenshot.save(shot_dir / f"shot_{int(time.time())}.png")
        """
        self._check_date_rollover()
        shot_dir = SCREENSHOTS_ROOT / self._current_date
        shot_dir.mkdir(parents=True, exist_ok=True)
        return shot_dir

    def get_session_dir(self) -> Path:
        """
        Get the path to today's session log folder.
        Useful if a module needs the folder path directly.

        Returns:
            Path object pointing to logs/sessions/YYYY-MM-DD/
        """
        self._check_date_rollover()
        return self._session_dir()

    def get_current_date(self) -> str:
        """
        Get today's date as a string (YYYY-MM-DD).
        Updates automatically if the date has changed.

        Returns:
            Date string like '2026-03-11'
        """
        self._check_date_rollover()
        return self._current_date

    # ── Internal helpers ───────────────────────────────────────────────────────

    def _today(self) -> str:
        """Get today's date as YYYY-MM-DD string."""
        return datetime.now().strftime("%Y-%m-%d")

    def _session_dir(self) -> Path:
        """Get the Path for today's session log folder."""
        return SESSIONS_ROOT / self._current_date

    def _ensure_dirs(self):
        """Create all required directories if they don't exist yet."""
        self._session_dir().mkdir(parents=True, exist_ok=True)
        (SCREENSHOTS_ROOT / self._current_date).mkdir(parents=True, exist_ok=True)
        PERSISTENT_ERRORS.parent.mkdir(parents=True, exist_ok=True)

    def _check_date_rollover(self):
        """
        Check if the date has changed since the last log entry.
        If it has, switch to a new dated folder and create it.

        This is called before every log write and every directory lookup,
        so Nova will always log to the correct date folder even if she
        runs continuously from 11pm into the next day.
        """
        today = self._today()
        if today != self._current_date:
            print(f"[logger] Date changed: {self._current_date} -> {today}")
            self._current_date = today
            self._ensure_dirs()
            print(f"[logger] Now logging to: {self._session_dir()}")


# ── Singleton instance ─────────────────────────────────────────────────────────
# All modules share this one logger instance.
# Importing nova_logger creates it once and reuses it everywhere.

_logger = NovaLogger()


# ── Module-level convenience functions ────────────────────────────────────────
# These are what other modules actually call.
# Much cleaner than passing a logger object around everywhere.

def log(log_type: str, event: str, **fields):
    """
    Write a log entry. See NovaLogger.log() for full documentation.

    This is the main function other modules should use:
        from nova_memory.logger import log
        log("actions", "success", target="Login button", action="click")
    """
    _logger.log(log_type, event, **fields)


def get_screenshot_dir() -> Path:
    """
    Get today's screenshot directory (auto-created).

    Usage:
        from nova_memory.logger import get_screenshot_dir
        shot_dir = get_screenshot_dir()
        screenshot.save(shot_dir / f"shot_{int(time.time())}.png")
    """
    return _logger.get_screenshot_dir()


def get_session_dir() -> Path:
    """Get today's session log directory."""
    return _logger.get_session_dir()


def get_current_date() -> str:
    """Get today's date string (YYYY-MM-DD), auto-updating."""
    return _logger.get_current_date()


# ── Standalone test ────────────────────────────────────────────────────────────

if __name__ == "__main__":
    """
    Run this to verify the logger works:
        python tools/nova_logger.py

    It will create today's log folders and write a test entry to each log type.
    Check logs/sessions/YYYY-MM-DD/ afterward to confirm.
    """
    print("=== NovaLogger Self-Test ===")
    print(f"Today's date: {get_current_date()}")
    print(f"Session dir:  {get_session_dir()}")
    print(f"Screenshot dir: {get_screenshot_dir()}")
    print()

    print("Writing test entries to each log type...")
    log("actions",    "test_entry", target="Test button",  action="click",  result="ok")
    log("mentor",     "test_entry", message="Test question from Nova")
    log("interrupts", "test_entry", message="Test message from Cole", classification="NORMAL")
    log("errors",     "test_entry", module="nova_logger",  error="This is a test error")

    print()
    print(f"Done. Check: {get_session_dir()}")
    print("You should see: actions.jsonl, mentor.jsonl, interrupts.jsonl, errors.jsonl")
    print(f"And persistent error log: {PERSISTENT_ERRORS}")
