#!/usr/bin/env python3
"""
nova_patch.py -- Post-Restructure Patch and Test Script
=========================================================
Patches any remaining files that still use old flat imports after the
nova_restructure.py migration, runs import tests on all packages,
then deletes the old flat files if everything passes.

Run: python tools/nova_patch.py
Run with --dry to preview without applying changes.
Run with --keep to patch and test but not delete old flat files.

Steps:
    1. Patch old flat import references in nova_watcher.py and other
       entry-point files that weren't updated by nova_restructure.py
    2. Import-test every package module to catch missing dependencies
    3. Smoke-test key classes can be instantiated
    4. Delete old flat .py files from tools/ root if all tests pass
"""

import sys
import importlib
import traceback
from pathlib import Path

WORKSPACE_DIR = Path(__file__).parent.parent
TOOLS_DIR = WORKSPACE_DIR / "tools"
DRY_RUN = "--dry" in sys.argv
KEEP_OLD = "--keep" in sys.argv

# -- Old flat files to delete after successful tests --------------------------
# These have been migrated into packages. Safe to delete once tests pass.
OLD_FLAT_FILES = [
    "nova_autonomy.py",
    "nova_backup.py",
    "nova_brain.py",
    "nova_checkin.py",
    "nova_drive.py",
    "nova_explorer.py",
    "nova_eyes.py",
    "nova_hands.py",
    "nova_journal.py",
    "nova_log_reader.py",
    "nova_logger.py",
    "nova_mentor.py",
    "nova_rules.py",
    "nova_state.py",
    "nova_status.py",
    "nova_verify.py",
    "nova_vision.py",
    "nova_vision_backup.py",
]

# -- Patches: files that need import updates ----------------------------------
# Each entry: (file_path_relative_to_tools, [(old_import, new_import), ...])
PATCHES = [
    # nova_watcher.py -- entry point, calls drive and backup
    ("nova_watcher.py", [
        ("from nova_drive import sync_to_drive",
         "from nova_sync.drive import sync_to_drive"),
        ("from nova_backup import run_backup",
         "from nova_sync.backup import run_backup"),
    ]),
    # nova_sync/watcher.py -- may reference other nova modules
    ("nova_sync/watcher.py", [
        ("from nova_drive import",   "from nova_sync.drive import"),
        ("from nova_backup import",  "from nova_sync.backup import"),
    ]),
    # nova_sync/drive.py
    ("nova_sync/drive.py", [
        ("from nova_logger import",  "from nova_memory.logger import"),
    ]),
    # nova_sync/backup.py
    ("nova_sync/backup.py", [
        ("from nova_logger import",  "from nova_memory.logger import"),
        ("from nova_drive import",   "from nova_sync.drive import"),
    ]),
    # nova_advisor/mentor.py
    ("nova_advisor/mentor.py", [
        ("from nova_logger import",  "from nova_memory.logger import"),
    ]),
    # nova_action/autonomy.py
    ("nova_action/autonomy.py", [
        ("from nova_logger import",  "from nova_memory.logger import"),
        ("from nova_eyes import",    "from nova_perception.eyes import"),
        ("from nova_hands import",   "from nova_action.hands import"),
        ("from nova_rules import",   "from nova_core.rules import"),
        ("from nova_checkin import", "from nova_core.checkin import"),
    ]),
    # nova_action/verify.py
    ("nova_action/verify.py", [
        ("from nova_logger import",  "from nova_memory.logger import"),
        ("from nova_eyes import",    "from nova_perception.eyes import"),
    ]),
    # nova_perception/eyes.py
    ("nova_perception/eyes.py", [
        ("from nova_logger import",    "from nova_memory.logger import"),
        ("from nova_explorer import",  "from nova_perception.explorer import"),
        ("from nova_vision import",    "from nova_perception.vision import"),
    ]),
    # nova_perception/vision.py
    ("nova_perception/vision.py", [
        ("from nova_logger import",  "from nova_memory.logger import"),
    ]),
    # nova_perception/explorer.py
    ("nova_perception/explorer.py", [
        ("from nova_logger import",  "from nova_memory.logger import"),
    ]),
    # nova_memory/journal.py
    ("nova_memory/journal.py", [
        ("from nova_logger import",  "from nova_memory.logger import"),
    ]),
    # nova_memory/status.py
    ("nova_memory/status.py", [
        ("from nova_logger import",  "from nova_memory.logger import"),
    ]),
    # nova_core/brain.py
    ("nova_core/brain.py", [
        ("from nova_logger import",  "from nova_memory.logger import"),
        ("from nova_rules import",   "from nova_core.rules import"),
    ]),
    # nova_core/checkin.py
    ("nova_core/checkin.py", [
        ("from nova_logger import",  "from nova_memory.logger import"),
    ]),
]

# -- Package import tests -----------------------------------------------------
# Each entry: (import_statement, description)
IMPORT_TESTS = [
    # Import the actual public names from each module (functions/classes that exist)
    ("from nova_memory.logger import log",           "nova_memory.logger"),
    ("from nova_memory.journal import append",       "nova_memory.journal"),
    ("from nova_memory.log_reader import summarize_today", "nova_memory.log_reader"),
    ("from nova_memory.state import NovaState",      "nova_memory.state"),
    ("from nova_core.rules import OPERATIONAL_DIRECTIVES", "nova_core.rules"),
    ("from nova_core.brain import NovaBrain",        "nova_core.brain"),
    ("from nova_core.checkin import init_session",   "nova_core.checkin"),
    ("from nova_sync.backup import run_backup",      "nova_sync.backup"),
    ("from nova_sync.drive import sync_to_drive",    "nova_sync.drive"),
]

# Mentor has heavy deps (anthropic) -- test module loads not class init
MENTOR_TESTS = [
    ("import nova_advisor.mentor",                   "nova_advisor.mentor (module load)"),
]

# Perception and action imports may fail without hardware libs -- warn not fail
SOFT_IMPORT_TESTS = [
    ("import nova_perception.eyes",       "nova_perception.eyes"),
    ("import nova_perception.explorer",   "nova_perception.explorer"),
    ("import nova_action.hands",          "nova_action.hands"),
    ("import nova_action.autonomy",       "nova_action.autonomy"),
]


# -- Helpers ------------------------------------------------------------------

def log(msg, level="INFO"):
    prefix = "[DRY] " if DRY_RUN else ""
    symbols = {"INFO": "  ", "OK": "✓ ", "WARN": "⚠ ", "FAIL": "✗ ", "HEAD": "=="}
    print(f"{prefix}{symbols.get(level, '  ')}{msg}")


def patch_file(rel_path, patches):
    """Apply import patches to a file. Returns True if any changes made."""
    path = TOOLS_DIR / rel_path
    if not path.exists():
        log(f"SKIP (not found): {rel_path}", "WARN")
        return False

    try:
        content = path.read_text(encoding="utf-8")
    except Exception as e:
        log(f"SKIP (read error): {rel_path} -- {e}", "WARN")
        return False

    original = content
    for old, new in patches:
        content = content.replace(old, new)

    if content == original:
        log(f"No changes needed: {rel_path}", "OK")
        return False

    if not DRY_RUN:
        path.write_text(content, encoding="utf-8")
    log(f"Patched: {rel_path}", "OK")
    return True


def run_import_test(import_stmt, description, soft=False):
    """Try to execute an import statement. Returns True if successful."""
    import subprocess
    test_cmd = f"import sys; sys.path.insert(0, r'{TOOLS_DIR}'); {import_stmt}; print('OK')"
    result = subprocess.run(
        [sys.executable, "-c", test_cmd],
        capture_output=True, text=True
    )
    if result.returncode == 0:
        log(f"{description}", "OK")
        return True
    else:
        err = result.stderr.strip().split('\n')[-1]
        if soft:
            log(f"{description} (soft fail -- hardware lib missing?): {err}", "WARN")
            return True  # don't count soft failures as blocking
        else:
            log(f"{description}: {err}", "FAIL")
            return False


def delete_old_files():
    """Delete old flat files from tools/ root."""
    deleted = 0
    for filename in OLD_FLAT_FILES:
        path = TOOLS_DIR / filename
        if path.exists():
            if not DRY_RUN:
                path.unlink()
            log(f"Deleted: {filename}", "OK")
            deleted += 1
        else:
            log(f"Already gone: {filename}", "INFO")
    return deleted


# -- Main ---------------------------------------------------------------------

def main():
    log("Nova Post-Restructure Patch and Test", "HEAD")
    log(f"Mode: {'DRY RUN' if DRY_RUN else 'LIVE'}", "HEAD")
    log("=" * 50, "HEAD")
    print()

    # Step 1: Apply patches
    log("STEP 1: Applying import patches", "HEAD")
    patched = 0
    for rel_path, patches in PATCHES:
        if patch_file(rel_path, patches):
            patched += 1
    log(f"Patched {patched} files.")
    print()

    if DRY_RUN:
        log("Dry run -- skipping tests and deletion.")
        return

    # Step 2: Import tests
    log("STEP 2: Running import tests", "HEAD")
    failures = 0

    for import_stmt, description in IMPORT_TESTS:
        if not run_import_test(import_stmt, description, soft=False):
            failures += 1

    log("Mentor/advisor tests:")
    for import_stmt, description in MENTOR_TESTS:
        run_import_test(import_stmt, description, soft=True)

    log("Soft tests (hardware libs may be missing):")
    for import_stmt, description in SOFT_IMPORT_TESTS:
        run_import_test(import_stmt, description, soft=True)

    print()
    if failures > 0:
        log(f"FAILED: {failures} import test(s) failed. NOT deleting old files.", "FAIL")
        log("Fix the failures above, then re-run nova_patch.py", "FAIL")
        sys.exit(1)

    log(f"All {len(IMPORT_TESTS)} import tests passed.", "OK")
    print()

    # Step 3: Delete old flat files
    if KEEP_OLD:
        log("STEP 3: Skipped (--keep flag set)", "HEAD")
        log("Old flat files preserved. Remove --keep to delete them on next run.")
    else:
        log("STEP 3: Deleting old flat files from tools/ root", "HEAD")
        deleted = delete_old_files()
        log(f"Deleted {deleted} old flat files.")
        print()
        log("Migration complete. Package structure is now the source of truth.", "OK")
        log("Both import styles still work via __init__.py re-exports.", "OK")


if __name__ == "__main__":
    main()
