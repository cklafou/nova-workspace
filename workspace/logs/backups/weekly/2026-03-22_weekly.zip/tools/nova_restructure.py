#!/usr/bin/env python3
# Last updated: 2026-03-21 05:45:00
"""
nova_restructure.py -- Tool Package Migration Script
=====================================================
Restructures tools/ from flat files into organized Python packages.

Run once: python tools/nova_restructure.py
Run with --dry to preview changes without applying them.

Package structure:
    tools/
        nova_sync/        -- File sync, watching, backup (watcher, drive, backup)
        nova_memory/      -- Logging, journal, state, status, log reading
        nova_advisor/     -- Mentor (Claude bridge)
        nova_action/      -- Hands, autonomy, verify
        nova_perception/  -- Eyes, explorer, vision
        nova_core/        -- Rules, brain, checkin, interrupt
        nova_comms/       -- (future: Discord, notifications)

Each package has an __init__.py that re-exports everything from the old
flat names so existing exec calls still work during transition.

After migration, both old and new import styles work:
    from nova_logger import log               # still works (compat)
    from nova_memory.logger import log        # new preferred style
"""

import sys
import shutil
import re
from pathlib import Path

WORKSPACE_DIR = Path(__file__).parent.parent
TOOLS_DIR = WORKSPACE_DIR / "tools"
DRY_RUN = "--dry" in sys.argv

# -- Package definitions ------------------------------------------------------
# package_name -> {new_module_name: old_filename}

PACKAGES = {
    "nova_sync": {
        "watcher": "nova_watcher.py",
        "drive":   "nova_drive.py",
        "backup":  "nova_backup.py",
    },
    "nova_memory": {
        "logger":     "nova_logger.py",
        "journal":    "nova_journal.py",
        "log_reader": "nova_log_reader.py",
        "status":     "nova_status.py",
        "state":      "nova_state.py",
    },
    "nova_advisor": {
        "mentor": "nova_mentor.py",
    },
    "nova_action": {
        "hands":    "nova_hands.py",
        "autonomy": "nova_autonomy.py",
        "verify":   "nova_verify.py",
    },
    "nova_perception": {
        "eyes":     "nova_eyes.py",
        "explorer": "nova_explorer.py",
        "vision":   "nova_vision.py",
        "vision_backup": "nova_vision_backup.py",
    },
    "nova_core": {
        "rules":   "nova_rules.py",
        "brain":   "nova_brain.py",
        "checkin": "nova_checkin.py",
        # nova_interrupt.py parked -- was causing unwanted autonomous calls
    },
}

# Flat files that stay in tools/ root (entry points, standalone scripts)
KEEP_AT_ROOT = {
    "nova_stress_tester.py",
    "nova_restructure.py",
}

# Import mapping: old flat import -> new package import
# Used to update imports across all files
IMPORT_MAP = {
    "from nova_watcher import":    "from nova_sync.watcher import",
    "import nova_watcher":         "import nova_sync.watcher as nova_watcher",
    "from nova_drive import":      "from nova_sync.drive import",
    "import nova_drive":           "import nova_sync.drive as nova_drive",
    "from nova_backup import":     "from nova_sync.backup import",
    "import nova_backup":          "import nova_sync.backup as nova_backup",
    "from nova_logger import":     "from nova_memory.logger import",
    "import nova_logger":          "import nova_memory.logger as nova_logger",
    "from nova_journal import":    "from nova_memory.journal import",
    "import nova_journal":         "import nova_memory.journal as nova_journal",
    "from nova_log_reader import": "from nova_memory.log_reader import",
    "from nova_status import":     "from nova_memory.status import",
    "from nova_state import":      "from nova_memory.state import",
    "from nova_mentor import":     "from nova_advisor.mentor import",
    "import nova_mentor":          "import nova_advisor.mentor as nova_mentor",
    "from nova_hands import":      "from nova_action.hands import",
    "from nova_autonomy import":   "from nova_action.autonomy import",
    "from nova_verify import":     "from nova_action.verify import",
    "from nova_eyes import":       "from nova_perception.eyes import",
    "from nova_explorer import":   "from nova_perception.explorer import",
    "from nova_vision import":     "from nova_perception.vision import",
    "from nova_rules import":      "from nova_core.rules import",
    "from nova_brain import":      "from nova_core.brain import",
    "from nova_checkin import":    "from nova_core.checkin import",
}


# -- Helpers ------------------------------------------------------------------

def log(msg):
    prefix = "[DRY RUN] " if DRY_RUN else ""
    print(f"{prefix}{msg}")


def make_dir(path):
    if not DRY_RUN:
        path.mkdir(parents=True, exist_ok=True)
    log(f"mkdir: {path.relative_to(TOOLS_DIR)}")


def copy_file(src, dst):
    if not DRY_RUN:
        shutil.copy2(src, dst)
    log(f"copy: {src.name} -> {dst.relative_to(TOOLS_DIR)}")


def write_file(path, content):
    if not DRY_RUN:
        path.write_text(content, encoding="utf-8")
    log(f"write: {path.relative_to(TOOLS_DIR)}")


def update_imports_in_file(path):
    """Update old flat imports to new package imports in a file."""
    try:
        content = path.read_text(encoding="utf-8")
    except Exception:
        return False

    original = content
    for old_import, new_import in IMPORT_MAP.items():
        content = content.replace(old_import, new_import)

    if content != original:
        if not DRY_RUN:
            path.write_text(content, encoding="utf-8")
        log(f"updated imports: {path.relative_to(TOOLS_DIR)}")
        return True
    return False


def make_init(package_dir, package_name, modules):
    """
    Create __init__.py that re-exports everything from submodules.
    This provides backward compatibility -- old flat-style imports still work.
    """
    lines = [
        f'"""',
        f'{package_name} -- Nova Tool Package',
        f'Re-exports all public names for backward compatibility.',
        f'Old style: from nova_logger import log  (still works)',
        f'New style: from nova_memory.logger import log  (preferred)',
        f'"""',
        '',
    ]

    for module_name, old_filename in modules.items():
        old_name = old_filename.replace('.py', '')
        lines.append(f'from nova_{package_name.split("_")[1] if "_" in package_name else package_name}.{module_name} import *  # noqa: F401,F403')

    lines.append('')
    lines.append('__all__ = []  # populated by wildcard imports above')

    init_path = package_dir / "__init__.py"
    write_file(init_path, "\n".join(lines) + "\n")


# -- Main migration -----------------------------------------------------------

def migrate():
    log(f"Nova Tool Package Migration")
    log(f"Tools dir: {TOOLS_DIR}")
    log(f"Mode: {'DRY RUN (no changes)' if DRY_RUN else 'LIVE'}")
    log("")

    # Step 1: Create package directories and copy files
    log("=== Step 1: Creating package directories ===")
    for package_name, modules in PACKAGES.items():
        package_dir = TOOLS_DIR / package_name
        make_dir(package_dir)

        for module_name, old_filename in modules.items():
            src = TOOLS_DIR / old_filename
            dst = package_dir / f"{module_name}.py"

            if src.exists():
                copy_file(src, dst)
            else:
                log(f"WARNING: {old_filename} not found -- skipping")

        # Create package __init__.py
        make_init(package_dir, package_name, modules)
        log("")

    # Step 2: Update imports in all package files
    log("=== Step 2: Updating imports in package files ===")
    for package_name in PACKAGES:
        package_dir = TOOLS_DIR / package_name
        for py_file in package_dir.glob("*.py"):
            if py_file.name == "__init__.py":
                continue
            update_imports_in_file(py_file)
    log("")

    # Step 3: Update imports in root-level tool files
    log("=== Step 3: Updating imports in root files ===")
    for py_file in TOOLS_DIR.glob("*.py"):
        if py_file.name in KEEP_AT_ROOT or py_file.name.startswith("__"):
            continue
        update_imports_in_file(py_file)
    log("")

    # Step 4: Summary
    log("=== Migration complete ===")
    log("")
    log("Package structure created:")
    for package_name, modules in PACKAGES.items():
        log(f"  tools/{package_name}/")
        for module_name in modules:
            log(f"    {module_name}.py")
    log("")
    log("Original flat files preserved in tools/ root (safe to delete later).")
    log("Both import styles now work during transition:")
    log("  from nova_logger import log          # old style (backward compat)")
    log("  from nova_memory.logger import log   # new preferred style")
    log("")
    if DRY_RUN:
        log("Re-run without --dry to apply changes.")


if __name__ == "__main__":
    migrate()
