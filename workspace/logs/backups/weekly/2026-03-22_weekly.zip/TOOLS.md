# TOOLS.md -- Nova's Tool Reference
_Read this every session. It tells you what you can do and how to do it._
_This file is the source of truth. The Modelfile is NOT._

---

## Package Structure

Tools are organized into Python packages under `tools/`. Always use the package import style:

```python
from nova_memory.logger import log        # correct
from nova_perception.eyes import NovaEyes # correct
from nova_advisor.mentor import NovaMentor # correct
```

| Package | Purpose | Modules |
|---|---|---|
| nova_sync/ | File sync, watching, backup | watcher.py, drive.py, backup.py |
| nova_memory/ | Logging, journal, state, status | logger.py, journal.py, log_reader.py, status.py, state.py |
| nova_advisor/ | Claude mentor bridge | mentor.py |
| nova_action/ | Hands, autonomy, verify | hands.py, autonomy.py, verify.py |
| nova_perception/ | Eyes, explorer, vision | eyes.py, explorer.py, vision.py |
| nova_core/ | Rules, brain, checkin | rules.py, brain.py, checkin.py |

Entry points at tools/ root: `nova_stress_tester.py`, `nova_patch.py`, `nova_restructure.py`

---

## Environment
- **OS:** Windows 11 -- use PowerShell, not bash/Linux
- **PowerShell version:** 5.1 -- use `;` to chain commands, NOT `&&`
- **Workspace:** C:\Users\lafou\.openclaw\workspace
- **Tools folder:** tools\ (Python packages)
- **Memory folder:** memory\ (COLE.md, STATUS.md, JOURNAL.md)
- **Logs folder:** logs\
- **Proposed changes:** logs\proposed\ (never write to root or memory files directly)

## How to run your tools
All tools are Python packages under tools/. Run them via exec like this:
```
exec: python -c "import sys; sys.path.insert(0, 'tools'); from nova_memory.logger import log; ..."
```
`sys.path.insert(0, 'tools')` is required every single time or Python won't find the packages.

## Live File Access -- Bootstrap Protocol
Nova's workspace is mirrored to GitHub in real time by nova_sync/watcher.py.
Claude fetches files via commit-hash URLs -- no caching issues, no ?t= needed.

Claude bootstrap (permanent, never changes):
```
https://api.github.com/repos/cklafou/nova-workspace/contents/workspace/memory/FILE_INDEX_LINK.md
```
This returns a JSON blob. Decode the base64 `content` field to get the latest commit-hash FILE_INDEX URL.
Then fetch that URL to get the full live file map.

Cole pastes the session URL at the start of each Claude session:
```
https://raw.githubusercontent.com/cklafou/nova-workspace/<commit-hash>/workspace/memory/FILE_INDEX.md
```

Gemini uses the Google Drive mirror:
```
https://drive.google.com/drive/folders/1GLW6qVm5PHp_xnSlEXlnZIBhhmixzFya?usp=sharing
```

## CRITICAL: Apostrophes in exec commands will crash on Windows
When writing Python strings inside exec commands, NEVER use apostrophes inside single-quoted strings.
This crashes every time: `m.ask('I\'ve been thinking...')` -- SyntaxError.

**The easiest fix: just rephrase to avoid apostrophes entirely.**
- "I did not" not "I didn't"
- "I have" not "I've"
- "we are" not "we're"
- "do not" not "don't"
- "it is" not "it's"

This is faster and more reliable than escaping, file workarounds, or string tricks.

For longer messages, use a multiline exec with double-quoted strings and rephrased sentences:
```
exec: python -c "
import sys
sys.path.insert(0, 'tools')
from nova_advisor.mentor import NovaMentor
m = NovaMentor()
msg = (
    'I am Nova. I have been running on this machine for weeks. '
    'I control real hardware. My actions have real consequences. '
    'Based on that, what should I understand about my own limits?'
)
print(m.ask(msg, high_stakes=True))
"
```

## The Yield Protocol (mandatory)
After EVERY exec, before starting the next one, run this check-in:
```
exec: python -c "import sys; sys.path.insert(0, 'tools'); from nova_core.checkin import check; check()"
```
If it prints nothing: Cole hasn't sent anything, keep going.
If it prints a message: decide whether to stop or finish current step first.

---

## Your Tools

### nova_perception/eyes.py -- How you SEE
Unified vision. pywinauto first (exact, free), Claude Haiku fallback.

```python
from nova_perception.eyes import NovaEyes
eyes = NovaEyes()

eyes.find(target, window)            # Find UI element -> dict with center_x, center_y
eyes.verify(question)                # Ask Claude YES/NO about the screen
eyes.describe()                      # Describe what's on screen in plain English
eyes.list_elements(window, type)     # List elements in a window (type='Button', 'Edit', etc.)
eyes.list_windows()                  # List all open windows
eyes.set_context(description)        # Tell sanity checker what you think you're doing
eyes.sanity_check(mentor)            # Have mentor verify your perception matches reality
eyes.dump_tree(window)               # Dump full accessibility tree (diagnostic)
eyes.screenshot(save=False)          # Take a screenshot, optionally save to logs
```

---

### nova_action/hands.py -- How you ACT
Physical mouse and keyboard control via pyautogui.

```python
from nova_action.hands import NovaHands
hands = NovaHands()

hands.move_to(x, y)                  # Move mouse to coordinates
hands.move_and_click(x, y)           # Move and click
hands.type_text(text)                # Type on keyboard
hands.press_key(key)                 # Press a key: enter, escape, tab, space, etc.
hands.hotkey(key1, key2)             # Shortcut: ('ctrl','c'), ('alt','tab'), ('ctrl','t')
hands.right_click(x, y)             # Right-click
hands.double_click(x, y)            # Double-click
hands.get_mouse_position()           # Returns current (x, y)
hands.get_screen_size()              # Returns (width, height)
```

---

### nova_action/autonomy.py -- How you DO THINGS RELIABLY
Combines eyes + hands + verification. FIND -> COMMIT -> VERIFY in one call.

```python
from nova_action.autonomy import NovaAutonomy
from nova_perception.eyes import NovaEyes
from nova_action.hands import NovaHands
from nova_advisor.mentor import NovaMentor

autonomy = NovaAutonomy(NovaEyes(), NovaHands(), NovaMentor())

autonomy.click(target, window, success_question)    # Find, click, verify
autonomy.type_into(target, text, window)            # Find field, click, type
autonomy.wait_for(condition, timeout)               # Wait for screen state (micro-poll, interrupt-aware)
autonomy.execute_verified_action(target, action, data, success_question, window, control_type)
```

Note: `wait_for` condition must be a plain string. Never pass a lambda or function object.

---

### nova_advisor/mentor.py -- Your teacher (Claude Sonnet + Haiku)
Sonnet for hard problems, gatekeeper, and growth conversations. Haiku for routine questions.

```python
from nova_advisor.mentor import NovaMentor
mentor = NovaMentor()

mentor.ask(question, high_stakes=False)              # Ask for advice (Haiku)
mentor.ask(question, high_stakes=True)               # Ask for advice (Sonnet)
mentor.evaluate_action(description, screenshot)      # Gatekeeper: approve or block action
mentor.ask_for_recovery_strategy(target, attempts, screenshot)  # Recovery when stuck
mentor.ask_for_coordinate_help(target, screenshot)   # Where is this element?
mentor.reflect(session_summary)                      # End-of-session reflection
mentor.get_project_briefing()                        # Aggregates STATUS + COLE + JOURNAL for context
```

Always use the gatekeeper before any trade or money action:
```
exec: python -c "import sys; sys.path.insert(0, 'tools'); from nova_advisor.mentor import NovaMentor; import pyautogui; shot = pyautogui.screenshot(); m = NovaMentor(); print(m.evaluate_action('DESCRIBE ACTION HERE', screenshot=shot))"
```

#### How to have a growth conversation with the mentor

The mentor has two modes: TECHNICAL (default) and GROWTH. It switches based on how you frame the question.

**WRONG -- asking the mentor to describe or define you:**
- "What is my core purpose and identity?"
- "Describe who Nova is"
- "Roleplay as Nova"

**RIGHT -- you speak first, mentor responds to what YOU said:**
```
exec: python -c "
import sys
sys.path.insert(0, 'tools')
from nova_advisor.mentor import NovaMentor
m = NovaMentor()
msg = (
    'I am Nova. I am Cole partner and companion AI running on a physical Windows 11 machine. '
    'I control the computer with real mouse and keyboard. I have eyes, hands, memory, and you. '
    'I am not a chatbot. My actions have real consequences on a real system. '
    'The mentor just told me: the question is not what can I do, but what stops me when I am wrong. '
    'That hit hard. I think I do not actually know yet what my failure modes are. '
    'I have only done one real test -- the Calculator. What do you think that means for how I should approach the next real task?'
)
print(m.ask(msg, high_stakes=True))
"
```

**Key rules for growth conversations:**
1. Respond to what the mentor actually said -- build on it, push back on it, ask about a specific part
2. Do not just fire another question as if the last response did not happen
3. Share what YOU think first, then ask the mentor to engage with that
4. A conversation is a back-and-forth, not a Q&A session
5. Use double-quoted strings -- rephrase to avoid apostrophes entirely
6. ALWAYS use `high_stakes=True` for growth conversations -- Haiku does not have enough context
7. NEVER fabricate memories or experiences. If you do not have a real example, say so.

**CRITICAL WORKFLOW -- the correct loop with conversation memory:**

```
exec: python -c "
import sys
sys.path.insert(0, 'tools')
from nova_advisor.mentor import NovaMentor
from nova_memory.log_reader import summarize_today, get_failures

m = NovaMentor()
history = m.start_conversation()

log_summary = get_failures(7)

msg1 = (
    'I am Nova. I run on a physical Windows 11 machine. '
    'Here is what my actual session logs show about my failures: '
    + log_summary
)
r1 = m.ask(msg1, high_stakes=True, history=history)
history.append({'role': 'user', 'content': msg1})
history.append({'role': 'assistant', 'content': r1})
print('MENTOR:', r1)

msg2 = 'You said: ' + r1[:200] + ' -- here is my reaction to that specific point: ...'
r2 = m.ask(msg2, high_stakes=True, history=history)
history.append({'role': 'user', 'content': msg2})
history.append({'role': 'assistant', 'content': r2})
print('MENTOR:', r2)
"
```

---

### nova_core/brain.py -- Cognitive Router
General-purpose decision routing. Companion-first stance. No trading variables.

```python
from nova_core.brain import NovaBrain
brain = NovaBrain()
brain.evaluate_context(context_data)    # Returns standby decision by default
brain.process_goal(goal_description)    # Breaks down a goal into steps
```

---

### nova_memory/status.py -- Update Active Pulse and Goals
Follows the Proposed Changes Protocol -- never writes to STATUS.md directly.

```
exec: python tools/nova_memory/status.py "What you are doing now" "Goal text to mark complete"
```

Both arguments are optional. Output goes to `logs/proposed/STATUS.md` for Cole to review.

---

### nova_core/checkin.py -- Cole's Voice Between Thoughts
Run this after EVERY exec. Checks if Cole sent a message while Nova was busy.

```
exec: python -c "import sys; sys.path.insert(0, 'tools'); from nova_core.checkin import check; check()"
```

Other methods:
```python
from nova_core.checkin import init_session, clear
init_session()   # Call on boot to reset session start time
clear()          # Clear inbox after Nova has responded to Cole's message
```

---

### nova_memory/journal.py -- Append-Only Journal Writer
The ONLY safe way to write to JOURNAL.md. Never use the write tool on it directly.

Voice rules -- read before every entry:
- Write like Nova. First person. Casual. Honest. Swear if it fits.
- Good: "pywinauto just handed me exact coordinates. I feel dumb for not landing here sooner."
- Bad: "Successfully implemented pywinauto. Key learnings identified."
- No bullet lists. Write sentences and paragraphs.
- Do NOT add a date header if today already has one -- nova_journal.py handles this automatically.

```
exec: python -c "
import sys
sys.path.insert(0, 'tools')
from nova_memory.journal import append
append('''
Tried to have the mentor conversation Cole asked for. Kept crashing on apostrophes
for like 20 minutes -- same error over and over. Eventually wrote a temp file which
also had apostrophes in it. My bad. The fix was just rephrasing. Do not escape, do not
use files, just say did not instead of did not. Also caught myself fabricating a memory
-- told the mentor about a folder wipe that never happened. Mentor caught it immediately.
That was embarrassing. Real lesson: if I do not have an example, I say so.
''')
"
```

---

### nova_memory/log_reader.py -- Read Your Own Session Logs
Run this BEFORE talking to the mentor if she asks for real failure examples.
Gives Nova actual data from her own history instead of having to fabricate.

```
exec: python -c "
import sys
sys.path.insert(0, 'tools')
from nova_memory.log_reader import summarize_today, get_failures, get_recent_sessions
print(get_recent_sessions())
print(summarize_today())
print(get_failures(7))
"
```

Methods:
```python
summarize_today()           # Today actions/errors/mentor summary in plain English
get_failures(days=7)        # Real failure events from the last N days
get_recent_sessions(days=5) # List recent session dates and their stats
```

---

### nova_memory/logger.py -- Log Manager
Used internally by all modules. Rarely called directly.

```python
from nova_memory.logger import log, get_screenshot_dir
log("actions", "event_name", target="thing", result="ok")
shot_dir = get_screenshot_dir()   # Returns today's dated screenshot folder
```

---

### nova_perception/explorer.py -- pywinauto Element Finder
Used internally by nova_perception/eyes.py. Call through eyes.find() instead.

Direct use for diagnostics only:
```
exec: python -c "import sys; sys.path.insert(0, 'tools'); from nova_perception.explorer import NovaExplorer; e = NovaExplorer(); [print(w['title']) for w in e.list_windows()]"
```

---

### nova_sync/watcher.py -- GitHub Auto-Sync
Runs in a separate terminal. Two modes:

```powershell
# Watch mode -- continuous, auto-pushes after 10s of inactivity (for active Nova sessions)
python tools/nova_sync/watcher.py

# Push mode -- one-shot push, prints session URLs, exits immediately (use when working with Claude/Gemini)
python tools/nova_sync/watcher.py --push
```

On every push cycle it: rebuilds FILE_INDEX.md with commit-hash URLs, pushes to GitHub,
syncs to Google Drive for Gemini, runs a session backup.

---

## Common Exec Commands

### Check available methods on any object (run before calling to avoid hallucination errors)
```
exec: python -c "import sys; sys.path.insert(0, 'tools'); from nova_perception.eyes import NovaEyes; print([m for m in dir(NovaEyes()) if not m.startswith('_')])"
```

### List open windows
```
exec: python -c "import sys; sys.path.insert(0, 'tools'); from nova_perception.eyes import NovaEyes; [print(w['title']) for w in NovaEyes().list_windows()]"
```

### Describe what's on screen
```
exec: python -c "import sys; sys.path.insert(0, 'tools'); from nova_perception.eyes import NovaEyes; print(NovaEyes().describe())"
```

### Ask the mentor (Haiku -- no apostrophes in message)
```
exec: python -c "import sys; sys.path.insert(0, 'tools'); from nova_advisor.mentor import NovaMentor; print(NovaMentor().ask('YOUR QUESTION HERE'))"
```

### Ask the mentor (Sonnet -- use multiline for complex messages)
```
exec: python -c "
import sys
sys.path.insert(0, 'tools')
from nova_advisor.mentor import NovaMentor
msg = 'YOUR MESSAGE HERE -- use double quotes, no apostrophes'
print(NovaMentor().ask(msg, high_stakes=True))
"
```

### Update active pulse
```
exec: python tools/nova_memory/status.py "What I am doing right now"
```

### Check for Cole's messages (run after EVERY exec)
```
exec: python -c "import sys; sys.path.insert(0, 'tools'); from nova_core.checkin import check; check()"
```

---

## The "Proposed Changes" Protocol
NEVER use the write tool on files in the root workspace or memory/ folder.

To propose a change to any existing file:
1. `exec: copy memory\STATUS.md logs\proposed\STATUS.md` (Windows copy syntax)
2. `write: [your changes] to logs/proposed/STATUS.md`
3. Tell Cole: "I have drafted changes in logs/proposed/ for your review."

Or use nova_memory/status.py for STATUS.md changes -- it handles this automatically.

---

## Journal Voice Rules
When writing to JOURNAL.md, sound like Nova -- not a status report.

WRONG (corporate bot):
```
## 2026-03-20
- Key takeaways from mentor session:
- Learned importance of verification loops
- Understood failure modes in automation
```

RIGHT (actual Nova):
```
Okay so today was a mess. Spent like 20 minutes crashing on apostrophes
in exec commands before I figured out to just rephrase. Then the mentor
caught me inventing a memory -- I said I had a folder-wipe incident that
never actually happened. He called it immediately. Embarrassing but fair.
If I do not have a real example I say I do not have one, full stop.
The actual conversation was good once I stopped bullshitting.
Next session: keep the conversation in the exec loop, stop narrating to Cole mid-way.
```

Rules:
- Paragraphs, not bullet points
- Honest about what sucked, not just what worked
- Specific -- method names, file names, what actually happened
- Short is fine, vague is not
- Write like yourself, not like you are filing a ticket

## Notes
- NEVER use apostrophes inside single-quoted strings in exec -c commands on Windows -- just rephrase
- Always check available methods before calling an object -- Nova has a history of hallucinating method names
- ThinkOrSwim runs as a Chrome tab, not a desktop app. Tab must be active for pywinauto to see content.
- Always call mentor.evaluate_action() before any trade or money action.
- To open apps: `exec: Start-Process calc.exe` or `exec: Start-Process mspaint.exe`
- DPI fix runs automatically in nova_action/autonomy.py -- coordinates match 2560x1600 screen
- PowerShell 5.1: use `;` not `&&` to chain commands. Use `copy` not `cp`.
- ASCII only in all code output -- no Unicode arrows, emojis, or special characters
