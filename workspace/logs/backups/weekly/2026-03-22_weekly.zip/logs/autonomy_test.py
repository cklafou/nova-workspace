#!/usr/bin/env python3
"""
autonomy_test.py — Pipeline Verification Test (NovaEyes + Claude)
====================================================================
Tests the full Nova pipeline using Windows Calculator: 5 + 3 = 8

What this test proves:
  ✅ NovaEyes finds elements (pywinauto primary, Claude fallback)
  ✅ Nova's hands click exact coordinates
  ✅ Claude verifies each action succeeded
  ✅ Sanity check system works (mentor reviews mid-test)
  ✅ The FIND → COMMIT → VERIFY loop works end-to-end

Usage:
    python logs/autonomy_test.py
"""

import sys
import time
import subprocess
import os

# Add workspace root and tools to Python path
workspace_root = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, workspace_root)
sys.path.insert(0, os.path.join(workspace_root, "tools"))

# ── Import Nova's core modules ─────────────────────────────────────────────────
try:
    from nova_eyes    import NovaEyes
    from nova_hands   import NovaHands
    from nova_mentor  import NovaMentor
    from nova_autonomy import NovaAutonomy
    print("✅ All Nova modules imported successfully.")
except ImportError as e:
    print(f"❌ Import failed: {e}")
    print("   Run from workspace root: python logs/autonomy_test.py")
    sys.exit(1)


def run_test():
    print("\n" + "=" * 55)
    print("  Nova Autonomy Pipeline Test — Calculator 5 + 3 = 8")
    print("  Using: NovaEyes (pywinauto + Claude) + Mentor sanity checks")
    print("=" * 55 + "\n")

    # ── Step 1: Initialize ────────────────────────────────────────────────────
    print("[TEST] Initializing Nova's core systems...")
    try:
        eyes     = NovaEyes()
        hands    = NovaHands()
        mentor   = NovaMentor()
        autonomy = NovaAutonomy(eyes, hands, mentor)

        # Set sanity check to trigger after 2 actions for this test
        # (normally 10, but we want to verify it works)
        eyes.set_sanity_interval(2)

        print("✅ All systems initialized.\n")
    except Exception as e:
        print(f"❌ Initialization failed: {e}")
        return False

    # ── Step 2: Open Calculator ───────────────────────────────────────────────
    print("[TEST] Opening Windows Calculator...")
    try:
        subprocess.Popen("calc.exe")
        time.sleep(2)
        print("✅ Calculator launched.\n")
    except Exception as e:
        print(f"❌ Could not launch Calculator: {e}")
        return False

    # ── Step 3: Verify Calculator via Claude ──────────────────────────────────
    print("[TEST] Asking Claude if Calculator is visible...")
    if eyes.verify("Is the Windows Calculator application open and visible on screen?"):
        print("✅ Claude confirmed Calculator is visible.\n")
    else:
        print("❌ Claude could not confirm Calculator is open.")
        return False

    # ── Step 4: Check pywinauto sees the buttons ─────────────────────────────
    print("[TEST] Checking pywinauto can see Calculator elements...")
    buttons = eyes.list_elements("Calculator", control_type="Button")
    button_names = [b["name"] for b in buttons]

    required = ["Five", "Plus", "Three", "Equals"]
    missing = [r for r in required if r not in button_names]
    if missing:
        print(f"❌ Missing required buttons: {missing}")
        return False
    print(f"✅ All required buttons found ({len(buttons)} total).\n")

    # ── Step 5: Set context for sanity checks ─────────────────────────────────
    eyes.set_context("Performing 5 + 3 = 8 on Windows Calculator")

    # ── Step 6: Click 5 ──────────────────────────────────────────────────────
    print("[TEST] Clicking '5'...")
    if autonomy.click("Five", window="Calculator",
                      success_question="Does the Calculator display show the number 5?"):
        print("✅ PASS — Clicked '5'.\n")
    else:
        print("❌ FAIL — Could not click '5'.")
        return False

    # ── Step 7: Click + ──────────────────────────────────────────────────────
    print("[TEST] Clicking '+'...")
    if autonomy.click("Plus", window="Calculator",
                      success_question="Is the Calculator showing an addition operation?"):
        print("✅ PASS — Clicked '+'.\n")
    else:
        print("❌ FAIL — Could not click '+'.")
        return False

    # Note: After 2 actions, a sanity check should trigger automatically
    # on the next action (interval set to 2 above)

    # ── Step 8: Click 3 ──────────────────────────────────────────────────────
    print("[TEST] Clicking '3'...")
    if autonomy.click("Three", window="Calculator",
                      success_question="Does the Calculator display show the number 3?"):
        print("✅ PASS — Clicked '3'.\n")
    else:
        print("❌ FAIL — Could not click '3'.")
        return False

    # ── Step 9: Click = and verify 8 ─────────────────────────────────────────
    print("[TEST] Clicking '=' and verifying result...")
    if autonomy.click("Equals", window="Calculator",
                      success_question="Does the Calculator display show the number 8 as the result?"):
        print("✅ PASS — Calculator shows 8!\n")
    else:
        print("❌ FAIL — Could not verify the result is 8.")
        return False

    # ── Summary ────────────────────────────────────────────────────────────────
    print("=" * 55)
    print("  🟢 ALL TESTS PASSED")
    print("=" * 55)
    print()
    print("Pipeline verified:")
    print("  NovaEyes found all buttons via pywinauto (exact, instant)")
    print("  Claude verified each action succeeded")
    print("  Mentor sanity check ran mid-test")
    print("  Calculator computed 5 + 3 = 8")
    print()
    print("Nova is ready for real tasks.")
    return True


if __name__ == "__main__":
    success = run_test()
    sys.exit(0 if success else 1)
