# STATUS.md

## Active Pulse
- **Current Task:** System health check complete - all components functioning properly
 -- Project Nova Current State
_Nova updates this file via nova_status.py (proposed changes protocol). Never edit directly._
_Last updated: 2026-03-19 21:28:04_

---

## What Nova Actually Is
Nova is Cole's companion AI and life passion project. She is being built toward full autonomy
and genuine partnership -- the Cortana to Cole's Master Chief. The trading mission is one
future test of her autonomy -- not her identity, not her current focus, and not her purpose.

---

## Current Mission
Stabilize Nova's autonomy stack, validate reliability, and complete hardware upgrades
before attempting any real-world automation tasks. Nova is in active testing and development.
ThinkOrSwim automation is parked until the stack is proven solid.

---

## Architecture
| Component | Module | Status |
|---|---|---|
| Brain | Qwen3 Coder (Qwen3.5-35B-A3B) via Ollama | Running |
| Framework | OpenClaw (gateway on ws://127.0.0.1:18789) | Running |
| Hands | nova_hands.py (pyautogui + pynput) | Confirmed working |
| Eyes (unified) | nova_eyes.py (pywinauto + Claude Haiku fallback) | Built, tested, passing |
| Eyes (elements) | nova_explorer.py (pywinauto accessibility API) | Built, tested, exact coordinates |
| Eyes (vision) | nova_vision.py (Claude Haiku 4.5 for verification) | Built |
| Action Loop | nova_autonomy.py (FIND->COMMIT->VERIFY + micro-poll interrupt) | Built, Calculator test passes |
| Mentor | nova_mentor.py (Claude Sonnet 4.6 + Haiku 4.5, full project context) | Built, context fixed |
| Manual Override | nova_interrupt.py (Cole's manual message writer, accepts CLI args) | Built |
| Check-in | nova_checkin.py (inter-turn message listener) | Built |
| Status Updater | nova_status.py (proposed changes protocol) | Built |
| Logger | nova_logger.py (dated log folders, auto-rotation) | Built |
| Rules | nova_rules.py (immutable operating directives, yield protocol) | Fixed 2026-03-15 |
| Journal | nova_journal.py (append-only journal writer) | Built |
| Brain Router | nova_brain.py (companion-first, trading variables purged) | Fixed 2026-03-15 |
| GitHub Sync | nova_watcher.py (auto-commits workspace) | Built |

---

## API Configuration
| Service | Model | Role | Cost |
|---|---|---|---|
| Anthropic | Claude Haiku 4.5 | Vision verification, routine mentor questions | $0.25/$1.25 per MTok |
| Anthropic | Claude Sonnet 4.6 | Gatekeeper, recovery strategy, sanity checks | $3/$15 per MTok |

Estimated monthly cost: $15-20/month during active development.

---

## Hardware
| Setting | Current | After eGPU installed |
|---|---|---|
| Machine | Tracer VII Edge I17E, i9-13900HX | Same |
| Laptop GPU | RTX 4090 16GB (150W+25W) | Same |
| eGPU | RTX 3090 24GB arrived, waiting on case | RTX 3090 24GB via Oculink |
| Total VRAM | 16GB | 40GB |
| Ollama num_ctx | 32768 | 131072 |
| OpenClaw contextWindow | 32768 | 32768 |
| OpenClaw maxTokens | 16384 | 32768 |
| OpenClaw timeout | 86400s (24hr) | 86400s |

---

## Confirmed Working
- Hardware hook -- pyautogui mouse movement confirmed on physical session
- DPI fix -- ctypes SetProcessDpiAwareness(2) prevents Windows coordinate lying
- Gateway timeout -- extended to 24 hours
- Model swap -- Qwen 2.5 Abliterated -> Qwen3 Coder (fixed tool-calling failures)
- Log structure -- dated folders via nova_logger.py
- pywinauto -- exact element coordinates for Calculator, Paint, Chrome, ThinkOrSwim
- Calculator test -- 5+3=8 via pywinauto + Claude verification, zero retries, 16 seconds
- Multi-app test -- ThinkOrSwim + Chrome + Paint completed by Cole on 2026-03-15
- ThinkOrSwim accessibility -- 145 buttons visible when tab is active
- API migration -- Gemini fully replaced by Anthropic (Haiku + Sonnet)
- Mentor context -- get_project_briefing() injects file tree + tool source into Sonnet calls
- Mentor sanity checks -- periodic screenshot review by Sonnet catches hallucination
- GitHub sync -- nova_watcher.py auto-commits workspace to github.com/cklafou/nova-workspace
- Identity stabilized -- nova_brain.py trading variables purged, companion routing online
- Yield protocol -- Nova takes one action per turn, checks for Cole's messages between steps
- Session tracking -- nova_checkin.init_session() creates session_start.json on boot
- Discord routing -- Nova sends exec results to Discord before chaining next exec

---

## Current Blockers
- eGPU case not yet arrived -- RTX 3090 sitting idle, Oculink install pending
- Interrupt system is manual only -- Cole must run nova_interrupt.py from second terminal
- Nova occasionally hallucinates method names (e.g. NovaEyes.get_screen_size, NovaStatus class)
- Discord slow listener -- messages sometimes take 80-145 seconds to deliver

---

## Development History
**Phase 1 -- Browser Hooks:** Failed. Chrome extension could not bypass auth walls.

**Phase 2 -- Kinetic C2:** Partial. pyautogui hook worked but Gemini vision was unreliable.

**Phase 3 -- Vision + Mentor (Gemini):** Failed. Coordinates off by 50-100px. Mentor cheerleaded instead of diagnosing.

**Phase 4 -- pywinauto + Claude:** Breakthrough. Exact coordinates via Windows accessibility API.
Calculator test passed clean. Gemini replaced by Anthropic.

**Phase 5 -- Identity + Stability (2026-03-15):** Major overhaul. nova_brain.py purged of
trading variables. All memory files rewritten in Nova's voice. Yield protocol added.
Proposed changes protocol added. nova_checkin, nova_status, nova_interrupt built.

**Phase 6 -- Stack Validation (2026-03-19):** Active. Testing mentor context, interrupt
system, Discord routing. Hardware upgrade in progress (RTX 3090 arrived, case pending).
Skills integration planned next.

---

## Next Steps (In Order)
1. Install eGPU when case arrives -- unlock 40GB VRAM and 131k context
2. Explore ClawHub skills -- identify useful community skills to install
3. Build nova_state.py -- pre-condition state checking before any action
4. Wire brain (Qwen3/OpenClaw) to nova_eyes + nova_autonomy as callable tools
5. ThinkOrSwim automation -- ONLY after stack is proven solid via testing

---

## Known Issues
- Chrome Remote Desktop active = pyautogui may control CRD session, not physical screen
- Chrome tab must be active for pywinauto to see ThinkOrSwim web content
- Nova occasionally hallucinates API method names -- always check TOOLS.md before exec
- Nova has history of overwriting JOURNAL.md -- always use nova_journal.py
- NovaTrading and NovaStrategy modules are prototype/mock only
- nova_brain.py and nova_explorer.py (old versions) are legacy stubs
