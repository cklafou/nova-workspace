https://raw.githubusercontent.com/cklafou/nova-workspace/c3e68696d947c11353f9326c771360add8ae52d1/workspace/tools/nova_sync/FILE_INDEX.md
