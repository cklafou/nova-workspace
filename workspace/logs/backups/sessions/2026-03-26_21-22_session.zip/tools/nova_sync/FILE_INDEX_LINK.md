https://raw.githubusercontent.com/cklafou/nova-workspace/dbed23645ba520242e3503e8b12d8204bc12bebd/workspace/tools/nova_sync/FILE_INDEX.md
