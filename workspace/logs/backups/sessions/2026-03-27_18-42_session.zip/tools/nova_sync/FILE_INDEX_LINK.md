https://raw.githubusercontent.com/cklafou/nova-workspace/e44a76445e26686c6d0c095264d87f37542e2627/workspace/tools/nova_sync/FILE_INDEX.md
