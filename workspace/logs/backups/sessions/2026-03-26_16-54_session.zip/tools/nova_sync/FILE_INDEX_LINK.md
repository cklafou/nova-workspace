https://raw.githubusercontent.com/cklafou/nova-workspace/4912a62914bbbf0c69321efec786f3e5ebd7c2d4/workspace/tools/nova_sync/FILE_INDEX.md
