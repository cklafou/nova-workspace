# FILE_INDEX.md -- Nova Workspace Raw File Index
_Auto-generated on boot by nova_sync/watcher.py. Do not edit manually._
_Last updated: 2026-03-26 20:22:57_
_cache_key: 0000553_

Claude: all URLs below use a commit hash -- they are cache-proof.
Fetch any URL directly. No ?t= needed.
Example: https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/tools/nova_sync/watcher.py

## Root
- .clawhub/ (excluded)
- [AGENTS.md](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/AGENTS.md)
- [BOOTSTRAP.md](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/BOOTSTRAP.md)
- [build_launcher.py](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/build_launcher.py)
- [HEARTBEAT.md](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/HEARTBEAT.md)
- [IDENTITY.md](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/IDENTITY.md)
- node_modules/ (excluded)
- NovaChatLauncher.exe
- [NovaChatLauncher.py](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/NovaChatLauncher.py)
- [README.md](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/README.md)
- [SOUL.md](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/SOUL.md)
- [TOOLS.md](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/TOOLS.md)
- [USER.md](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/USER.md)

## _admin/
- [_admin/NOVA_PROJECT_PLAN.md](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/_admin/NOVA_PROJECT_PLAN.md)
- [_admin/passover/3%20MAR%202026/passover_2026-03-10.md](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/_admin/passover/3%20MAR%202026/passover_2026-03-10.md)
- [_admin/passover/3%20MAR%202026/passover_2026-03-15.md](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/_admin/passover/3%20MAR%202026/passover_2026-03-15.md)
- [_admin/passover/3%20MAR%202026/passover_2026-03-19.md](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/_admin/passover/3%20MAR%202026/passover_2026-03-19.md)
- [_admin/passover/3%20MAR%202026/passover_2026-03-20.md](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/_admin/passover/3%20MAR%202026/passover_2026-03-20.md)
- [_admin/passover/3%20MAR%202026/passover_2026-03-20_gemini.md](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/_admin/passover/3%20MAR%202026/passover_2026-03-20_gemini.md)
- [_admin/passover/3%20MAR%202026/passover_2026-03-21_claude.md](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/_admin/passover/3%20MAR%202026/passover_2026-03-21_claude.md)
- [_admin/passover/3%20MAR%202026/passover_2026-03-21_gemini.md](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/_admin/passover/3%20MAR%202026/passover_2026-03-21_gemini.md)
- [_admin/passover/3%20MAR%202026/passover_2026-03-21_gemini_session2.md](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/_admin/passover/3%20MAR%202026/passover_2026-03-21_gemini_session2.md)
- [_admin/passover/3%20MAR%202026/passover_2026-03-26_claude.md](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/_admin/passover/3%20MAR%202026/passover_2026-03-26_claude.md)
- [_admin/passover/3%20MAR%202026/session_notes_2026-03-22.md](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/_admin/passover/3%20MAR%202026/session_notes_2026-03-22.md)

## _build/
- _build/build/NovaChatLauncher/Analysis-00.toc
- _build/build/NovaChatLauncher/base_library.zip
- _build/build/NovaChatLauncher/EXE-00.toc
- _build/build/NovaChatLauncher/localpycs/pyimod01_archive.pyc
- _build/build/NovaChatLauncher/localpycs/pyimod02_importers.pyc
- _build/build/NovaChatLauncher/localpycs/pyimod03_ctypes.pyc
- _build/build/NovaChatLauncher/localpycs/pyimod04_pywin32.pyc
- _build/build/NovaChatLauncher/localpycs/struct.pyc
- _build/build/NovaChatLauncher/NovaChatLauncher.pkg
- _build/build/NovaChatLauncher/PKG-00.toc
- _build/build/NovaChatLauncher/PYZ-00.pyz
- _build/build/NovaChatLauncher/PYZ-00.toc
- [_build/build/NovaChatLauncher/warn-NovaChatLauncher.txt](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/_build/build/NovaChatLauncher/warn-NovaChatLauncher.txt)
- [_build/build/NovaChatLauncher/xref-NovaChatLauncher.html](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/_build/build/NovaChatLauncher/xref-NovaChatLauncher.html)
- _build/dist/NovaChatLauncher.exe
- _build/NovaChatLauncher.spec

## logs/
- logs/backups/sessions/2026-03-23_19-27_session.zip
- logs/backups/sessions/2026-03-25_11-55_session.zip
- logs/backups/sessions/2026-03-25_11-56_session.zip
- logs/backups/sessions/2026-03-25_12-23_session.zip
- logs/backups/sessions/2026-03-25_13-10_session.zip
- logs/backups/sessions/2026-03-25_13-25_session.zip
- logs/backups/sessions/2026-03-25_13-48_session.zip
- logs/backups/sessions/2026-03-25_14-09_session.zip
- logs/backups/sessions/2026-03-25_14-12_session.zip
- logs/backups/sessions/2026-03-25_14-18_session.zip
- logs/backups/sessions/2026-03-25_14-36_session.zip
- logs/backups/sessions/2026-03-25_14-39_session.zip
- logs/backups/sessions/2026-03-25_19-21_session.zip
- logs/backups/sessions/2026-03-25_19-25_session.zip
- logs/backups/sessions/2026-03-25_22-11_session.zip
- logs/backups/sessions/2026-03-25_22-25_session.zip
- logs/backups/sessions/2026-03-26_15-50_session.zip
- logs/backups/sessions/2026-03-26_16-01_session.zip
- logs/backups/sessions/2026-03-26_16-26_session.zip
- logs/backups/sessions/2026-03-26_16-28_session.zip
- logs/backups/sessions/2026-03-26_16-33_session.zip
- logs/backups/sessions/2026-03-26_16-54_session.zip
- logs/backups/sessions/2026-03-26_19-17_session.zip
- logs/backups/sessions/2026-03-26_19-27_session.zip
- logs/backups/sessions/2026-03-26_19-45_session.zip
- logs/backups/sessions/2026-03-26_19-53_session.zip
- logs/backups/sessions/2026-03-26_20-05_session.zip
- logs/backups/sessions/2026-03-26_20-18_session.zip
- logs/backups/weekly/2026-03-22_weekly.zip
- [logs/chat_sessions/2026-03-21_16-46-47_chat.jsonl](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/logs/chat_sessions/2026-03-21_16-46-47_chat.jsonl)
- [logs/chat_sessions/2026-03-21_19-26-26_chat.jsonl](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/logs/chat_sessions/2026-03-21_19-26-26_chat.jsonl)
- [logs/chat_sessions/exports/2026-03-21_19-26-26_context_claude.md](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/logs/chat_sessions/exports/2026-03-21_19-26-26_context_claude.md)
- [logs/chat_sessions/exports/2026-03-21_19-26-26_context_gemini.md](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/logs/chat_sessions/exports/2026-03-21_19-26-26_context_gemini.md)
- [logs/chat_sessions/sessions_index.json](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/logs/chat_sessions/sessions_index.json)
- [logs/proposed/nova_advisor_refactor.py](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/logs/proposed/nova_advisor_refactor.py)
- [logs/proposed/STATUS.md](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/logs/proposed/STATUS.md)
- [logs/sessions/2026-03-19/mentor.jsonl](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/logs/sessions/2026-03-19/mentor.jsonl)
- [logs/sessions/2026-03-20/mentor.jsonl](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/logs/sessions/2026-03-20/mentor.jsonl)
- [logs/sessions/2026-03-20/stress_test.jsonl](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/logs/sessions/2026-03-20/stress_test.jsonl)
- [logs/sessions/2026-03-22/system.jsonl](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/logs/sessions/2026-03-22/system.jsonl)
- [logs/sessions/2026-03-25/actions.jsonl](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/logs/sessions/2026-03-25/actions.jsonl)
- [logs/sessions/2026-03-26/actions.jsonl](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/logs/sessions/2026-03-26/actions.jsonl)
- [logs/sessions/2026-03-26/nova_thoughts.jsonl](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/logs/sessions/2026-03-26/nova_thoughts.jsonl)

## memory/
- [memory/archive/archive_2026-02.md](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/memory/archive/archive_2026-02.md)
- [memory/COLE.md](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/memory/COLE.md)
- [memory/JOURNAL.md](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/memory/JOURNAL.md)
- [memory/STATUS.md](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/memory/STATUS.md)

## tools/
- tools/backups/ (excluded)
- [tools/calls.py](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/tools/calls.py)
- [tools/Calls_Master_Index.md](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/tools/Calls_Master_Index.md)
- [tools/nova_action/__init__.py](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/tools/nova_action/__init__.py)
- tools/nova_action/__pycache__/ (excluded)
- [tools/nova_action/autonomy.py](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/tools/nova_action/autonomy.py)
- [tools/nova_action/calls.md](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/tools/nova_action/calls.md)
- [tools/nova_action/hands.py](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/tools/nova_action/hands.py)
- [tools/nova_action/verify.py](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/tools/nova_action/verify.py)
- [tools/nova_advisor/__init__.py](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/tools/nova_advisor/__init__.py)
- tools/nova_advisor/__pycache__/ (excluded)
- [tools/nova_advisor/calls.md](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/tools/nova_advisor/calls.md)
- [tools/nova_advisor/mentor.py](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/tools/nova_advisor/mentor.py)
- tools/nova_chat/__pycache__/ (excluded)
- [tools/nova_chat/calls.md](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/tools/nova_chat/calls.md)
- [tools/nova_chat/check_keys.py](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/tools/nova_chat/check_keys.py)
- tools/nova_chat/clients/__pycache__/ (excluded)
- [tools/nova_chat/clients/claude.py](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/tools/nova_chat/clients/claude.py)
- [tools/nova_chat/clients/gemini.py](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/tools/nova_chat/clients/gemini.py)
- [tools/nova_chat/clients/nova.py](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/tools/nova_chat/clients/nova.py)
- [tools/nova_chat/context_export.py](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/tools/nova_chat/context_export.py)
- [tools/nova_chat/launch.py](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/tools/nova_chat/launch.py)
- [tools/nova_chat/nova_bridge.py](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/tools/nova_chat/nova_bridge.py)
- [tools/nova_chat/orchestrator.py](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/tools/nova_chat/orchestrator.py)
- [tools/nova_chat/server.py](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/tools/nova_chat/server.py)
- [tools/nova_chat/server_runner.py](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/tools/nova_chat/server_runner.py)
- [tools/nova_chat/session_manager.py](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/tools/nova_chat/session_manager.py)
- [tools/nova_chat/static/index.html](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/tools/nova_chat/static/index.html)
- [tools/nova_chat/transcript.py](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/tools/nova_chat/transcript.py)
- [tools/nova_chat/workspace_context.py](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/tools/nova_chat/workspace_context.py)
- [tools/nova_core/__init__.py](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/tools/nova_core/__init__.py)
- tools/nova_core/__pycache__/ (excluded)
- [tools/nova_core/brain.py](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/tools/nova_core/brain.py)
- [tools/nova_core/calls.md](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/tools/nova_core/calls.md)
- [tools/nova_core/checkin.py](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/tools/nova_core/checkin.py)
- [tools/nova_core/rules.py](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/tools/nova_core/rules.py)
- [tools/nova_logs/__init__.py](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/tools/nova_logs/__init__.py)
- tools/nova_logs/__pycache__/ (excluded)
- [tools/nova_logs/calls.md](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/tools/nova_logs/calls.md)
- [tools/nova_logs/logger.py](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/tools/nova_logs/logger.py)
- [tools/nova_logs/Logger_Index.md](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/tools/nova_logs/Logger_Index.md)
- [tools/nova_memory/__init__.py](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/tools/nova_memory/__init__.py)
- tools/nova_memory/__pycache__/ (excluded)
- [tools/nova_memory/calls.md](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/tools/nova_memory/calls.md)
- [tools/nova_memory/journal.py](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/tools/nova_memory/journal.py)
- [tools/nova_memory/log_reader.py](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/tools/nova_memory/log_reader.py)
- [tools/nova_memory/state.py](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/tools/nova_memory/state.py)
- [tools/nova_memory/status.py](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/tools/nova_memory/status.py)
- [tools/nova_perception/__init__.py](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/tools/nova_perception/__init__.py)
- tools/nova_perception/__pycache__/ (excluded)
- [tools/nova_perception/calls.md](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/tools/nova_perception/calls.md)
- [tools/nova_perception/explorer.py](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/tools/nova_perception/explorer.py)
- [tools/nova_perception/eyes.py](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/tools/nova_perception/eyes.py)
- [tools/nova_perception/vision.py](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/tools/nova_perception/vision.py)
- [tools/nova_sync/__init__.py](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/tools/nova_sync/__init__.py)
- tools/nova_sync/__pycache__/ (excluded)
- [tools/nova_sync/backup.py](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/tools/nova_sync/backup.py)
- [tools/nova_sync/calls.md](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/tools/nova_sync/calls.md)
- [tools/nova_sync/dir_patch.py](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/tools/nova_sync/dir_patch.py)
- [tools/nova_sync/drive.py](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/tools/nova_sync/drive.py)
- tools/nova_sync/FILE_INDEX.md
- [tools/nova_sync/FILE_INDEX_LINK.md](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/tools/nova_sync/FILE_INDEX_LINK.md)
- [tools/nova_sync/GEMINI_INDEX.md](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/tools/nova_sync/GEMINI_INDEX.md)
- [tools/nova_sync/watcher.py](https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/tools/nova_sync/watcher.py)
