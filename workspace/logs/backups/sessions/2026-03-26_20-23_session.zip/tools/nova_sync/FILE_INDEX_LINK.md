https://raw.githubusercontent.com/cklafou/nova-workspace/27ec3e1cbc752377a0e7302a3538ee504106dc31/workspace/tools/nova_sync/FILE_INDEX.md
