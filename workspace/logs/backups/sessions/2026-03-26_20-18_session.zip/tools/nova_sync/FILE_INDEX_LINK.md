https://raw.githubusercontent.com/cklafou/nova-workspace/ff2efa2ce0d9a562124ee640c7bc95164abd0354/workspace/tools/nova_sync/FILE_INDEX.md
