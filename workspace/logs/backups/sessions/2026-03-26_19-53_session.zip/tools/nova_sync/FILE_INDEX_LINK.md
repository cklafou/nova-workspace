https://raw.githubusercontent.com/cklafou/nova-workspace/a3ffa4214703237098e9cb825562395569d615c1/workspace/tools/nova_sync/FILE_INDEX.md
