# FILE_INDEX.md -- Nova Workspace Raw File Index
_Auto-generated on boot by nova_sync/watcher.py. Do not edit manually._
_Last updated: 2026-03-27 18:16:25_
_cache_key: 0000557_

Claude: all URLs below use a commit hash -- they are cache-proof.
Fetch any URL directly. No ?t= needed.
Example: https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/nova_sync/watcher.py

## Root
- .clawhub/ (excluded)
- __pycache__/ (excluded)
- [AGENTS.md](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/AGENTS.md)
- [BOOTSTRAP.md](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/BOOTSTRAP.md)
- [HEARTBEAT.md](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/HEARTBEAT.md)
- [IDENTITY.md](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/IDENTITY.md)
- [nova_gateway.json](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/nova_gateway.json)
- [nova_gateway_runner.py](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/nova_gateway_runner.py)
- [README.md](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/README.md)
- [SOUL.md](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/SOUL.md)
- [TOOLS.md](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/TOOLS.md)
- [USER.md](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/USER.md)

## _admin/
- [_admin/COWORK_SESSION_LOG.md](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/_admin/COWORK_SESSION_LOG.md)
- [_admin/migrate_to_project_nova.py](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/_admin/migrate_to_project_nova.py)
- [_admin/NOVA_PROJECT_PLAN.md](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/_admin/NOVA_PROJECT_PLAN.md)
- [_admin/passover/3%20MAR%202026/passover_2026-03-10.md](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/_admin/passover/3%20MAR%202026/passover_2026-03-10.md)
- [_admin/passover/3%20MAR%202026/passover_2026-03-15.md](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/_admin/passover/3%20MAR%202026/passover_2026-03-15.md)
- [_admin/passover/3%20MAR%202026/passover_2026-03-19.md](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/_admin/passover/3%20MAR%202026/passover_2026-03-19.md)
- [_admin/passover/3%20MAR%202026/passover_2026-03-20.md](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/_admin/passover/3%20MAR%202026/passover_2026-03-20.md)
- [_admin/passover/3%20MAR%202026/passover_2026-03-20_gemini.md](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/_admin/passover/3%20MAR%202026/passover_2026-03-20_gemini.md)
- [_admin/passover/3%20MAR%202026/passover_2026-03-21_claude.md](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/_admin/passover/3%20MAR%202026/passover_2026-03-21_claude.md)
- [_admin/passover/3%20MAR%202026/passover_2026-03-21_gemini.md](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/_admin/passover/3%20MAR%202026/passover_2026-03-21_gemini.md)
- [_admin/passover/3%20MAR%202026/passover_2026-03-21_gemini_session2.md](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/_admin/passover/3%20MAR%202026/passover_2026-03-21_gemini_session2.md)
- [_admin/passover/3%20MAR%202026/passover_2026-03-26_claude.md](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/_admin/passover/3%20MAR%202026/passover_2026-03-26_claude.md)
- [_admin/passover/3%20MAR%202026/session_notes_2026-03-22.md](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/_admin/passover/3%20MAR%202026/session_notes_2026-03-22.md)
- [_admin/PHASE2_ARCHITECTURE.md](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/_admin/PHASE2_ARCHITECTURE.md)

## _build/
- _build/build_nova/Nova/Analysis-00.toc
- _build/build_nova/Nova/base_library.zip
- _build/build_nova/Nova/EXE-00.toc
- _build/build_nova/Nova/localpycs/pyimod01_archive.pyc
- _build/build_nova/Nova/localpycs/pyimod02_importers.pyc
- _build/build_nova/Nova/localpycs/pyimod03_ctypes.pyc
- _build/build_nova/Nova/localpycs/pyimod04_pywin32.pyc
- _build/build_nova/Nova/localpycs/struct.pyc
- _build/build_nova/Nova/Nova.pkg
- _build/build_nova/Nova/PKG-00.toc
- _build/build_nova/Nova/PYZ-00.pyz
- _build/build_nova/Nova/PYZ-00.toc
- [_build/build_nova/Nova/warn-Nova.txt](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/_build/build_nova/Nova/warn-Nova.txt)
- [_build/build_nova/Nova/xref-Nova.html](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/_build/build_nova/Nova/xref-Nova.html)
- _build/Nova/Nova.exe
- _build/Nova.spec

## logs/
- logs/backups/sessions/2026-03-25_11-55_session.zip
- logs/backups/sessions/2026-03-25_11-56_session.zip
- logs/backups/sessions/2026-03-25_12-23_session.zip
- logs/backups/sessions/2026-03-25_13-10_session.zip
- logs/backups/sessions/2026-03-25_13-25_session.zip
- logs/backups/sessions/2026-03-25_13-48_session.zip
- logs/backups/sessions/2026-03-25_14-09_session.zip
- logs/backups/sessions/2026-03-25_14-12_session.zip
- logs/backups/sessions/2026-03-25_14-18_session.zip
- logs/backups/sessions/2026-03-25_14-36_session.zip
- logs/backups/sessions/2026-03-25_14-39_session.zip
- logs/backups/sessions/2026-03-25_19-21_session.zip
- logs/backups/sessions/2026-03-25_19-25_session.zip
- logs/backups/sessions/2026-03-25_22-11_session.zip
- logs/backups/sessions/2026-03-25_22-25_session.zip
- logs/backups/sessions/2026-03-26_15-50_session.zip
- logs/backups/sessions/2026-03-26_16-01_session.zip
- logs/backups/sessions/2026-03-26_16-26_session.zip
- logs/backups/sessions/2026-03-26_16-28_session.zip
- logs/backups/sessions/2026-03-26_16-33_session.zip
- logs/backups/sessions/2026-03-26_16-54_session.zip
- logs/backups/sessions/2026-03-26_19-17_session.zip
- logs/backups/sessions/2026-03-26_19-27_session.zip
- logs/backups/sessions/2026-03-26_19-45_session.zip
- logs/backups/sessions/2026-03-26_19-53_session.zip
- logs/backups/sessions/2026-03-26_20-05_session.zip
- logs/backups/sessions/2026-03-26_20-18_session.zip
- logs/backups/sessions/2026-03-26_20-23_session.zip
- logs/backups/sessions/2026-03-26_21-22_session.zip
- logs/backups/sessions/2026-03-27_18-14_session.zip
- logs/backups/weekly/2026-03-22_weekly.zip
- [logs/chat_sessions/2026-03-21_16-46-47_chat.jsonl](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/logs/chat_sessions/2026-03-21_16-46-47_chat.jsonl)
- [logs/chat_sessions/2026-03-21_19-26-26_chat.jsonl](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/logs/chat_sessions/2026-03-21_19-26-26_chat.jsonl)
- [logs/chat_sessions/exports/2026-03-21_19-26-26_context_claude.md](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/logs/chat_sessions/exports/2026-03-21_19-26-26_context_claude.md)
- [logs/chat_sessions/exports/2026-03-21_19-26-26_context_gemini.md](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/logs/chat_sessions/exports/2026-03-21_19-26-26_context_gemini.md)
- [logs/chat_sessions/sessions_index.json](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/logs/chat_sessions/sessions_index.json)
- [logs/proposed/nova_advisor_refactor.py](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/logs/proposed/nova_advisor_refactor.py)
- [logs/sessions/2026-03-19/mentor.jsonl](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/logs/sessions/2026-03-19/mentor.jsonl)
- [logs/sessions/2026-03-20/mentor.jsonl](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/logs/sessions/2026-03-20/mentor.jsonl)
- [logs/sessions/2026-03-20/stress_test.jsonl](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/logs/sessions/2026-03-20/stress_test.jsonl)
- [logs/sessions/2026-03-22/system.jsonl](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/logs/sessions/2026-03-22/system.jsonl)
- [logs/sessions/2026-03-25/actions.jsonl](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/logs/sessions/2026-03-25/actions.jsonl)
- [logs/sessions/2026-03-26/actions.jsonl](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/logs/sessions/2026-03-26/actions.jsonl)
- [logs/sessions/2026-03-26/nova_thoughts.jsonl](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/logs/sessions/2026-03-26/nova_thoughts.jsonl)

## memory/
- [memory/archive/archive_2026-02.md](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/memory/archive/archive_2026-02.md)
- [memory/COLE.md](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/memory/COLE.md)
- [memory/JOURNAL.md](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/memory/JOURNAL.md)
- [memory/STATUS.md](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/memory/STATUS.md)

## sessions/
- [sessions/2026-03-27/27319801-a1e2-4172-9754-550105bfac1f.jsonl](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/sessions/2026-03-27/27319801-a1e2-4172-9754-550105bfac1f.jsonl)

## tools/
- tools/__pycache__/ (excluded)
- tools/backups/ (excluded)
- [tools/build_nova.py](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/build_nova.py)
- [tools/calls.py](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/calls.py)
- [tools/Calls_Master_Index.md](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/Calls_Master_Index.md)
- [tools/nova_action/__init__.py](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/nova_action/__init__.py)
- [tools/nova_action/autonomy.py](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/nova_action/autonomy.py)
- [tools/nova_action/calls.md](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/nova_action/calls.md)
- [tools/nova_action/hands.py](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/nova_action/hands.py)
- [tools/nova_action/verify.py](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/nova_action/verify.py)
- [tools/nova_advisor/__init__.py](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/nova_advisor/__init__.py)
- [tools/nova_advisor/calls.md](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/nova_advisor/calls.md)
- [tools/nova_advisor/mentor.py](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/nova_advisor/mentor.py)
- tools/nova_chat/__pycache__/ (excluded)
- [tools/nova_chat/calls.md](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/nova_chat/calls.md)
- [tools/nova_chat/check_keys.py](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/nova_chat/check_keys.py)
- tools/nova_chat/clients/__pycache__/ (excluded)
- [tools/nova_chat/clients/claude.py](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/nova_chat/clients/claude.py)
- [tools/nova_chat/clients/gemini.py](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/nova_chat/clients/gemini.py)
- [tools/nova_chat/clients/nova.py](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/nova_chat/clients/nova.py)
- [tools/nova_chat/context_export.py](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/nova_chat/context_export.py)
- [tools/nova_chat/launch.py](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/nova_chat/launch.py)
- [tools/nova_chat/nova_bridge.py](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/nova_chat/nova_bridge.py)
- [tools/nova_chat/orchestrator.py](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/nova_chat/orchestrator.py)
- [tools/nova_chat/server.py](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/nova_chat/server.py)
- [tools/nova_chat/server_runner.py](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/nova_chat/server_runner.py)
- [tools/nova_chat/session_manager.py](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/nova_chat/session_manager.py)
- [tools/nova_chat/static/index.html](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/nova_chat/static/index.html)
- [tools/nova_chat/transcript.py](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/nova_chat/transcript.py)
- [tools/nova_chat/workspace_context.py](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/nova_chat/workspace_context.py)
- [tools/nova_core/__init__.py](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/nova_core/__init__.py)
- tools/nova_core/__pycache__/ (excluded)
- [tools/nova_core/brain.py](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/nova_core/brain.py)
- [tools/nova_core/calls.md](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/nova_core/calls.md)
- [tools/nova_core/checkin.py](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/nova_core/checkin.py)
- [tools/nova_core/nova_status.py](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/nova_core/nova_status.py)
- [tools/nova_core/rules.py](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/nova_core/rules.py)
- [tools/nova_gateway/__init__.py](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/nova_gateway/__init__.py)
- tools/nova_gateway/__pycache__/ (excluded)
- [tools/nova_gateway/agent_loop.py](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/nova_gateway/agent_loop.py)
- [tools/nova_gateway/config.py](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/nova_gateway/config.py)
- [tools/nova_gateway/context_builder.py](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/nova_gateway/context_builder.py)
- [tools/nova_gateway/discord_client.py](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/nova_gateway/discord_client.py)
- [tools/nova_gateway/gateway.py](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/nova_gateway/gateway.py)
- [tools/nova_gateway/scheduler.py](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/nova_gateway/scheduler.py)
- [tools/nova_gateway/session_store.py](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/nova_gateway/session_store.py)
- [tools/nova_gateway/tool_executor.py](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/nova_gateway/tool_executor.py)
- [tools/nova_logs/__init__.py](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/nova_logs/__init__.py)
- tools/nova_logs/__pycache__/ (excluded)
- [tools/nova_logs/calls.md](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/nova_logs/calls.md)
- [tools/nova_logs/logger.py](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/nova_logs/logger.py)
- [tools/nova_logs/Logger_Index.md](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/nova_logs/Logger_Index.md)
- [tools/nova_memory/__init__.py](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/nova_memory/__init__.py)
- [tools/nova_memory/calls.md](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/nova_memory/calls.md)
- [tools/nova_memory/journal.py](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/nova_memory/journal.py)
- [tools/nova_memory/log_reader.py](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/nova_memory/log_reader.py)
- [tools/nova_memory/state.py](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/nova_memory/state.py)
- [tools/nova_memory/status.py](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/nova_memory/status.py)
- [tools/nova_perception/__init__.py](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/nova_perception/__init__.py)
- [tools/nova_perception/calls.md](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/nova_perception/calls.md)
- [tools/nova_perception/explorer.py](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/nova_perception/explorer.py)
- [tools/nova_perception/eyes.py](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/nova_perception/eyes.py)
- [tools/nova_perception/vision.py](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/nova_perception/vision.py)
- [tools/nova_sync/__init__.py](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/nova_sync/__init__.py)
- tools/nova_sync/__pycache__/ (excluded)
- [tools/nova_sync/backup.py](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/nova_sync/backup.py)
- [tools/nova_sync/calls.md](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/nova_sync/calls.md)
- [tools/nova_sync/dir_patch.py](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/nova_sync/dir_patch.py)
- [tools/nova_sync/drive.py](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/nova_sync/drive.py)
- tools/nova_sync/FILE_INDEX.md
- [tools/nova_sync/FILE_INDEX_LINK.md](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/nova_sync/FILE_INDEX_LINK.md)
- [tools/nova_sync/GEMINI_INDEX.md](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/nova_sync/GEMINI_INDEX.md)
- [tools/nova_sync/watcher.py](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/nova_sync/watcher.py)
- [tools/NovaLauncher.py](https://raw.githubusercontent.com/cklafou/nova-workspace//workspace/tools/NovaLauncher.py)
