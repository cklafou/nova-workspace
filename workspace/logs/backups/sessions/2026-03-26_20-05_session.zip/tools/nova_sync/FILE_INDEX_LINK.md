https://raw.githubusercontent.com/cklafou/nova-workspace/579f6f2c5e3e970ee25d0728af60dfa0dc3bf22e/workspace/tools/nova_sync/FILE_INDEX.md
