https://raw.githubusercontent.com/cklafou/nova-workspace/39b077eca67e4413d6bd102c85a979230d576e5f/workspace/tools/nova_sync/FILE_INDEX.md
