https://raw.githubusercontent.com/cklafou/nova-workspace/936d77cdbc5f670b57b66c11ef0d41d033bd45e6/workspace/tools/nova_sync/FILE_INDEX.md
