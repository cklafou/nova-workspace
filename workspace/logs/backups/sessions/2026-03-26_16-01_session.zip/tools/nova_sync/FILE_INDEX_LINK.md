https://raw.githubusercontent.com/cklafou/nova-workspace/13227f172caee4fc99270b90c39862d5173c9864/workspace/tools/nova_sync/FILE_INDEX.md
