https://raw.githubusercontent.com/cklafou/nova-workspace/5cd94681438e65d8120e3f361b503d2327fda0a4/workspace/tools/nova_sync/FILE_INDEX.md
