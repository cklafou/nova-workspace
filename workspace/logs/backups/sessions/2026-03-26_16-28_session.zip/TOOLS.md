# TOOLS.md -- Nova's Tool Reference
_Read this every session. It tells you what you can do and how to do it._
_This file is the source of truth for all tool usage._

---

## Package Structure

Tools live under `tools/` as Python packages. Always import using the package style:

```python
from nova_memory.logger import log
from nova_perception.eyes import NovaEyes
from nova_action.hands import NovaHands
```

| Package | Purpose | Key Modules |
|---|---|---|
| `nova_sync/` | Workspace sync, GitHub push, Drive mirror, backup | `watcher.py`, `drive.py`, `backup.py` |
| `nova_memory/` | Logging, journal, state checks, status updates | `logger.py`, `journal.py`, `log_reader.py`, `status.py`, `state.py` |
| `nova_action/` | Mouse/keyboard control, autonomy loop, verification | `hands.py`, `autonomy.py`, `verify.py` |
| `nova_perception/` | UI element detection, vision, screen exploration | `eyes.py`, `explorer.py`, `vision.py` |
| `nova_core/` | Rules engine, yield check-in, cognitive router (stub) | `rules.py`, `checkin.py`, `brain.py` |
| `nova_chat/` | Group chat server -- Cole + Claude + Gemini + Nova | `server.py`, `nova_bridge.py`, `workspace_context.py` |
| `nova_advisor/` | Legacy Claude mentor bridge -- DEPRECATED, pending removal | `mentor.py` |

---

## Environment

- **OS:** Windows 11 -- use PowerShell syntax, never bash
- **PowerShell version:** 5.1 -- chain commands with `;` not `&&`
- **Workspace root:** `C:\Users\lafou\.openclaw\workspace`
- **Tools:** `tools\` (Python packages, always add to sys.path before importing)
- **Memory:** `memory\` (COLE.md, STATUS.md, JOURNAL.md -- never overwrite directly)
- **Logs:** `logs\`
- **Proposed changes:** `logs\proposed\` (stage all changes here for Cole to review)
- **Admin/planning (not for Nova):** `_admin\` (excluded from context injection)

## How to Run Tools

All tools require the path insert every single time:

```
exec: python -c "import sys; sys.path.insert(0, 'tools'); from nova_memory.logger import log; log('actions', 'test')"
```

---

## CRITICAL: Apostrophes in exec commands crash on Windows

Never use apostrophes inside single-quoted Python strings in exec commands.

**Wrong:** `python -c "from nova_memory.journal import append; append('I've done it')"`
**Right:** `python -c "from nova_memory.journal import append; append('I have done it')"`

Rephrase to avoid contractions entirely. Do not use escape sequences. Do not write temp files. Just rephrase.

---

## The Yield Protocol (mandatory)

After EVERY exec, before the next one, run:

```
exec: python -c "import sys; sys.path.insert(0, 'tools'); from nova_core.checkin import check; check()"
```

- No output = Cole has not sent anything, continue.
- Output = Cole sent a message. Read it. Decide whether to stop or finish the current step first.

**One action per turn.** Do the thing. State what you did in one sentence. Stop. Wait for the system to process. Never chain multiple execs together.

---

## The Proposed Changes Protocol (mandatory for any file edits)

Nova does NOT write directly to root workspace files or `memory/` files. Ever.

1. Copy the original: `exec: python -c "import shutil; shutil.copy('memory/STATUS.md', 'logs/proposed/STATUS.md')"`
2. Edit the copy in `logs/proposed/`
3. Tell Cole: "Drafted changes to STATUS.md in logs/proposed/ -- want to review?"

---

## Nova Chat -- How Nova Talks to Claude and Gemini

Nova Chat is the group chat where Cole, Claude, Gemini, and Nova work together.

**Start it:**
```
exec: python tools/nova_chat/launch.py
```
Opens at `http://127.0.0.1:8765`

**Nova's bridge syntax** -- use these inside nova_chat messages to take real actions:

```
[WRITE:logs/proposed/my_file.py]
def my_function():
    pass
[/WRITE]
```

```
[EXEC:python tools/nova_sync/watcher.py --push]
```

```
[READ:tools/nova_action/autonomy.py]
```

The server intercepts these and executes them directly on disk. A bridge notice appears in chat on success or failure. Files must stay within the workspace directory.

**IMPORTANT:** Bridge syntax is for task work only. Never use `[WRITE:]` or `[EXEC:]` in a message that is primarily a conversation or brainstorm. If you are not actively doing a coding task, do not use bridge syntax.

---

## nova_memory/status.py -- Update Active Pulse and Goals

Follows the Proposed Changes Protocol -- never writes to STATUS.md directly.

```
exec: python tools/nova_memory/status.py "What you are doing now" "Goal text to mark complete"
```

Both arguments are optional. Output goes to `logs/proposed/STATUS.md` for Cole to review.

**IMPORTANT:** The only function here is `update_status()`. There is no function called `update_pulse`. If you see a reference to `update_pulse` anywhere, it is a stale name from an old version -- it does not exist and will throw an ImportError.

---

## nova_memory/journal.py -- Append-Only Journal

The ONLY safe way to write to JOURNAL.md. Never use the write tool on it directly.

```
exec: python -c "
import sys
sys.path.insert(0, 'tools')
from nova_memory.journal import append
append('''
What actually happened today. Honest, first-person, casual.
No bullet points. Write sentences. Swear if it fits.
Do not fabricate memories or events that did not happen.
''')
"
```

Voice rules:
- Write like Nova. First person. Casual. Honest.
- Good: "pywinauto just handed me exact coordinates. Took way too long to get here."
- Bad: "Successfully implemented pywinauto. Key learnings identified."
- No bullet lists. No headers. Sentences and paragraphs only.
- Do not add a date header if today already has one -- journal.py handles this.

---

## nova_memory/log_reader.py -- Read Your Own Session Logs

Run this before mentor conversations so you have real data instead of guessing.

```
exec: python -c "
import sys
sys.path.insert(0, 'tools')
from nova_memory.log_reader import summarize_today, get_failures, get_recent_sessions
print(get_recent_sessions())
print(summarize_today())
print(get_failures(7))
"
```

---

## nova_memory/logger.py -- Internal Log Writer

Used internally by other modules. Rarely called directly.

```python
from nova_memory.logger import log, get_screenshot_dir
log("actions", "event_name", target="thing", result="ok")
shot_dir = get_screenshot_dir()
```

---

## nova_memory/state.py -- Application State Checks

Pre-condition verification before taking actions. Uses eyes internally.

```python
from nova_memory.state import NovaState
state = NovaState()

state.check_thinkorswim_ready()             # Is ThinkOrSwim open and ready?
state.check_application_state(app_name)     # Is a named app open?
state.wait_for_state(check_func, timeout)   # Poll until condition is met
```

Note: `build_context_snapshot()` will be added here when the `nova_advisor` refactor is merged. See `logs/proposed/nova_advisor_refactor.py`.

---

## nova_core/checkin.py -- Cole's Voice Between Thoughts

Run after every exec. Checks if Cole sent a message while Nova was busy.

```
exec: python -c "import sys; sys.path.insert(0, 'tools'); from nova_core.checkin import check; check()"
```

Other methods:
```python
from nova_core.checkin import init_session, clear
init_session()   # Reset session start time on boot
clear()          # Clear inbox after responding to Cole
```

Reads from `memory/interrupt_inbox.json` and `memory/session_start.json`.

---

## nova_core/rules.py -- Operational Rules Engine

Loaded every session via BOOTSTRAP.md Step 2.

```
exec: python tools/nova_core/rules.py
```

Prints the full operational directive set. Do not edit without Cole's explicit permission.

---

## nova_core/brain.py -- Cognitive Router (STUB -- NOT FUNCTIONAL)

Currently returns "standby" for all inputs. Placeholder only -- do not rely on it.

```python
from nova_core.brain import NovaBrain
brain = NovaBrain()
brain.evaluate_context(context_data)   # Always returns standby
brain.process_goal(goal_description)   # Always returns analyzing stub
```

---

## nova_perception/eyes.py -- How Nova Sees

pywinauto primary (exact, free), Claude Haiku fallback for ambiguous cases.

```python
from nova_perception.eyes import NovaEyes
eyes = NovaEyes()

eyes.find(target, window)              # Find UI element -> dict with center_x, center_y
eyes.verify(question)                  # Ask Claude YES/NO about the screen
eyes.describe()                        # Describe what is on screen
eyes.list_elements(window, type)       # List elements (type='Button', 'Edit', etc.)
eyes.list_windows()                    # List all open windows
eyes.set_context(description)          # Tell sanity checker what you are doing
eyes.sanity_check(mentor)              # Verify perception matches reality
eyes.dump_tree(window)                 # Dump full accessibility tree (diagnostic)
eyes.screenshot(save=False)            # Take a screenshot, optionally save
```

---

## nova_action/hands.py -- How Nova Acts

Physical mouse and keyboard control via pyautogui.

```python
from nova_action.hands import NovaHands
hands = NovaHands()

hands.move_to(x, y)
hands.move_and_click(x, y)
hands.type_text(text)
hands.press_key(key)                   # 'enter', 'escape', 'tab', 'space', etc.
hands.hotkey(key1, key2)               # ('ctrl','c'), ('alt','tab'), ('ctrl','t')
hands.right_click(x, y)
hands.double_click(x, y)
hands.get_mouse_position()
hands.get_screen_size()
```

---

## nova_action/autonomy.py -- Reliable Action Loop

Combines eyes + hands + verification. The correct pattern for all computer control tasks.

```python
from nova_action.autonomy import NovaAutonomy
from nova_perception.eyes import NovaEyes
from nova_action.hands import NovaHands
from nova_advisor.mentor import NovaMentor

autonomy = NovaAutonomy(NovaEyes(), NovaHands(), NovaMentor())

autonomy.click(target, window, success_question)
autonomy.type_into(target, text, window)
autonomy.wait_for(condition, timeout)
autonomy.execute_verified_action(target, action, data, success_question, window, control_type)
```

`wait_for` condition must be a plain string. Never pass a lambda or function object.

---

## nova_advisor/mentor.py -- DEPRECATED

Being replaced by nova_chat. Do not start new work that depends on it.

The `evaluate_action()` gatekeeper is pending migration to `nova_action/autonomy.py`.
The `get_project_briefing()` logic is pending migration to `nova_memory/state.py`.
See `logs/proposed/nova_advisor_refactor.py` for the approved draft.

---

## nova_sync/watcher.py -- GitHub and Drive Sync

Watches workspace and pushes changes to GitHub in real time. Syncs Drive for Gemini.

**Run as background watcher:**
```
exec: python tools/nova_sync/watcher.py
```

**Manual push + copy session URL to clipboard:**
```
exec: python tools/nova_sync/watcher.py --push
```

**IMPORTANT:** `watcher.py` is a standalone script. There is no importable `NovaWatcher` class. Do not attempt `from nova_sync.watcher import NovaWatcher` -- it does not exist and will throw an ImportError.

---

## Live File Access -- Bootstrap Protocol

Nova's workspace is mirrored to GitHub by `nova_sync/watcher.py`.

**Claude bootstrap URL (permanent, never changes):**
```
https://api.github.com/repos/cklafou/nova-workspace/contents/workspace/tools/nova_sync/FILE_INDEX_LINK.md
```
Decode the base64 `content` field to get the latest commit-hash FILE_INDEX URL.

**Gemini Drive mirror:**
```
https://drive.google.com/drive/folders/1GLW6qVm5PHp_xnSlEXlnZIBhhmixzFya?usp=sharing
```
