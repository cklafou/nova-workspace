https://raw.githubusercontent.com/cklafou/nova-workspace/5d12ebde8fb3862096086d0299b2d6d2e1ee793b/workspace/tools/nova_sync/FILE_INDEX.md
