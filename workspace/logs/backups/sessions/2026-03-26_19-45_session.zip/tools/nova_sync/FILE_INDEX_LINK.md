https://raw.githubusercontent.com/cklafou/nova-workspace/57f93f2151b1364764599582b6a4d6fcd17922d0/workspace/tools/nova_sync/FILE_INDEX.md
