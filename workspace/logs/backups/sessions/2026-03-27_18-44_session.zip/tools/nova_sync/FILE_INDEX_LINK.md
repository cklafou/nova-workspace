https://raw.githubusercontent.com/cklafou/nova-workspace/bdef2ad747dec86e8d8fa1645367d5ba3d4a743d/workspace/tools/nova_sync/FILE_INDEX.md
